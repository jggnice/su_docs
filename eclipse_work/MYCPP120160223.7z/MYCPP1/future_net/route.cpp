#include "route.h"
#include "lib/lib_record.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int isValid(int column, short unsigned int *res, int vim)
{
	int i;
	if (res[vim - 1] == res[column])
		return 0;
	for (i = 0; i < column; i++)
		if (res[i] == res[column])
			return 0;
	return 1;
}
void search_route1(char *topo[5000], int edge_num, char *demand, int vim)
{

	unsigned short result[666]; //
	int num_of_demand = 0;
	int i, j;
	int loc;
	int adjacent[600][8] =
	{ 0 };
	int adjindex[600] =
	{ 0 };
	int adjindex1[600] =
	{ 0 };
	j = 0;
	int des[52];
	//char s[] = "ab-cd : ef;gh :i-jkl;mnop;qrs-tu: vwx-y;z";
	char delim[3] = ",|";
	char *p;
	des[j++] = atoi(strtok(demand, delim));
	while ((p = strtok(NULL, delim)))
		des[j++] = atoi(p);
	num_of_demand = j;
	for (i = 0; i < 600; i++)
		for (j = 0; j < 8; j++)
		{
			adjacent[i][j] = 666;
		}
	for (i = 0; i < 666; i++)
	{
		result[i] = 666;
	}
	result[0] = des[0];
	result[vim - 1] = des[1];

	for (i = 0; i < edge_num; i++)
	{

		int a1, a2, a3, a4;
		sscanf(topo[i], "%d,%d,%d,%d", &a1, &a2, &a3, &a4);
		//printf("\n-%d-%d-",a2,a3);
		adjacent[a2][adjindex[a2]] = a3;
		adjindex[a2]++;
	}
//////////////////////////////////////////////////////////
	loc = 1;
	while (1)
	{
		if (result[loc] == 666)
		{
			result[loc] = adjacent[result[loc - 1]][0];
			adjindex1[loc - 1]++;
		}
		if (isValid(loc, result, vim))
		{
			if (loc == vim - TWO)
			{
				//here need prove the last point
				for (i = 0; i < vim; i++)
				{
					printf("\n%d->", result[i]);
				}
				return;
			}
			else
				loc++;
			//end
		}
		else if (adjindex1[loc - 1] < 7)
		{
			result[loc] = adjacent[result[loc - 1]][adjindex1[loc - 1]];
			adjindex1[loc - 1]++;
			//end
		}
		else
		{
			while (adjindex1[loc - 1] == 7)
			{
				if (loc == 1)
				{
					for (i = 0; i < vim; i++)
					{
						printf("\n%d->", result[i]);
					}
					return;
				}
				result[loc] = 666;
				adjindex1[loc - 1] = 0;
				loc--;
			}
			result[loc] = adjacent[result[loc - 1]][adjindex1[loc - 1]];
			adjindex1[loc - 1]++;
		}
	}
	puts("__my__");
//output NA
//if(edge_num > 0)return;
//output  is not NA

//    for (int i = 0; i < 3; i++)
//    record_result(result[i]);
}
void search_route(char *topo[5000], int edge_num, char *demand)
{
	search_route1(topo, edge_num, demand, 3);
//output NA
//if(edge_num > 0)return;
//output  is not NA

//    for (int i = 0; i < 3; i++)
//    record_result(result[i]);
}
