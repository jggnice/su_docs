#ifndef __ROUTE_H__
#define __ROUTE_H__

#define FOUR 4
#define TWO 2
#define NOVALE -1
#define Pn 666
#define En 5000
void search_route(char *graph[5000], int edge_num, char *condition);

#endif
