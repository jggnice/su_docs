package rt5_1;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;

@SuppressWarnings("serial")
class AboutFrame extends JFrame
{
    public AboutFrame()
    {
       setSize(400,300);
       setResizable(true);
       setTitle("����");
       Toolkit tk=Toolkit.getDefaultToolkit();
       Image ff=tk.getImage("src/rt5_1/image/false.gif");
       setIconImage(ff);
       Dimension screenSize=tk.getScreenSize();
       setLocation((screenSize.width-400)/2,(screenSize.height-300)/2);
       FontPanel fpanel=new FontPanel();
       Container con=getContentPane();
       con.add(fpanel);
    }
}