package rt5_1;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

@SuppressWarnings("serial")
class SimpleFrame extends JFrame {

	public SimpleFrame() {
		setSize(WIDTH, HEIGHT);
		setResizable(false);
		setTitle("�����壨10*10��");
		Toolkit tk = Toolkit.getDefaultToolkit();
		Image img = tk.getImage(ImagePanel.class.getResource("image/map.gif"));
		setIconImage(img);
		Dimension screenSize = tk.getScreenSize();
		setLocation((screenSize.width - WIDTH) / 2,
				(screenSize.height - HEIGHT) / 2);

		final AboutFrame aboutFrame = new AboutFrame();
		ImagePanel panel = new ImagePanel();
		Container contentPane = getContentPane();
		contentPane.add(panel);

		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);

		JMenu gameMenu = new JMenu("��Ϸ(G)"); // ������Ϸ�˵�
		gameMenu.setMnemonic('G');

		// ������Ϸ�Ӳ˵���������
		JMenuItem replayItem = new JMenuItem("����", 'R');
		replayItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R,
				InputEvent.CTRL_MASK));
		replayItem.addActionListener(new AbstractAction("����") {
			public void actionPerformed(ActionEvent event) {
				ImagePanel.restart();
				panel.repaint();
			}
		});
		JMenuItem optionItem = new JMenuItem("ѡ��", 'O');
		optionItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
				InputEvent.CTRL_MASK));
		optionItem.addActionListener(new AbstractAction("ѡ��") {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent event) {

			}
		});

		JMenuItem exitItem = new JMenuItem("�˳�", 'E');
		exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,
				InputEvent.CTRL_MASK));
		exitItem.addActionListener(new AbstractAction("�˳�") {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent event) {
				System.exit(0);
			}
		});
		gameMenu.add(replayItem);
		gameMenu.add(optionItem);
		gameMenu.addSeparator();
		gameMenu.add(exitItem);
		menuBar.add(gameMenu);

		JMenu helpMenu = new JMenu("����(H)"); // ���������˵�
		helpMenu.setMnemonic('H');
		// ���������Ӳ˵���������
		JMenuItem aboutItem = new JMenuItem("����", 'A');
		aboutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,
				InputEvent.CTRL_MASK));
		aboutItem.addActionListener(new AbstractAction("����") {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent event) {
				aboutFrame.show();
			}
		});
		helpMenu.add(aboutItem);
		menuBar.add(helpMenu);

	}

	public static final int WIDTH = 560;
	public static final int HEIGHT = 520;
	public static final int OUT_OF_FRAME = 50;
	public static final int freeBall = 0;
	public static final int playerBall = 1;
	public static final int computerBall = 2;
}