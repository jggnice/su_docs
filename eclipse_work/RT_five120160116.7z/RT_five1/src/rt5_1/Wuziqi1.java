package rt5_1;

import javax.swing.JFrame;

public class Wuziqi1
{
   @SuppressWarnings("deprecation")
public static void main(String[] args)
   {
      SimpleFrame frame=new SimpleFrame();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.show();

   }
}
