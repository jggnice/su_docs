package rt5_1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

/***********************************************************************************/
final class ImagePanel extends JPanel
{

	/**
	 * The Variable Declarations
	 * 
	 */
	private static int Boardsize = 10;
	private static int numberofwinpaths = 2 * Boardsize * (Boardsize - 5 + 1) + 2
			* (Boardsize - 5 + 1) * (Boardsize - 5 + 1);
	private static final long serialVersionUID = 1L;
	private static final int impossible = 7;
	private int[] GradeRank = {5,50,100,4000};
	private static int littleGrade = 100;
	private static int bigGrade = 4000;	
	private Image image;
	private Image position;
	private Image green;
	private Image red;
	private Image ired;
	private static int xMouse, yMouse;
	private static int ball[][] = new int[Boardsize][Boardsize];
	// POSITIONS
	private static boolean ptable[][][] = new boolean[Boardsize][Boardsize][numberofwinpaths];
	private static boolean ctable[][][] = new boolean[Boardsize][Boardsize][numberofwinpaths];
	// REMEMBER
	private static int playerGrades[][] = new int[Boardsize][Boardsize];
	private static int computerGrades[][] = new int[Boardsize][Boardsize];
	private static int TheMaxComputerGrade = 0, TheMaxPlayerGrade = 0;
	// WEIGHT
	private static int win[][] = new int[2][numberofwinpaths];
	private static int playerChessCount, computerChessCount;
	// COUNT CHESS
	private static boolean IsPlayerTurn, IsComputerTurn;
	private static boolean GameJustStarted = true, GameIsOver = false;
	private static boolean PlayerWinsTheGame, ComputerWinsTheGame, GameIsATie;
	private static int i, j, k;
	private static int count, mComputerLastBall = SimpleFrame.OUT_OF_FRAME,
			nComputerLastBall = SimpleFrame.OUT_OF_FRAME;
	private static int n, m;
	// Drop At Point(m,n)
	private static int mAttack, nAttack, mDefend, nDefend;
	private static int MessageToShow = 0;
	// STATE
	final static int Message_Baby_you_first = 0;
	final static int Message_Baby_you_wait = 1;
	final static int Message_Baby_you_go = 2;
	final static int Message_Baby_you_good = 3;
	final static int Message_Baby_you_fool = 4;
	final static int Message_Baby_you_not_win = 5;

	// Playerdo
	public void playerdo(MouseEvent evnt)
	{
		if (!GameIsOver)
		{
			xMouse = evnt.getX();
			yMouse = evnt.getY();

			if (IsPlayerTurn)
			{
				int x = getxx(getWidth());
				int y = getyy(getHeight());
				if (MouseInTheBoard(xMouse, yMouse, x, y))
				{
					m = getIndex(xMouse, x);
					n = getIndex(yMouse, y);
					while (ball[m][n] == SimpleFrame.freeBall)
					{
						ball[m][n] = SimpleFrame.playerBall;
						playerChessCount++;
						MessageToShow = Message_Baby_you_wait;
						checkIfTie();
						checkTableforPlayer();
						if (!GameIsOver)
						{
							checkIfWhoWins();
						}
						if (GameIsOver)
						{
							showGameOverInfomation();
						}
						if (!GameIsOver)
						{
							IsPlayerTurn = false;
							IsComputerTurn = true;
							repaint();
							computerdo();
						}
					}
				} else
				{
					return;
				}
			}

		}
	}

	public void computerdo()
	{
		if (!GameIsOver)
			if (IsComputerTurn)
			{
				countPlayerGrades();
				countComputerGrades();
				if (GameJustStarted)
				{
					if (ball[(Boardsize - 1) / 2][(Boardsize - 1) / 2] == SimpleFrame.freeBall)
					{
						m = (Boardsize - 1) / 2;
						n = m;
					} else
					{
						m = (Boardsize + 1) / 2;
						n = m;
					}
					GameJustStarted = false;
				} else
				{
					checkBestPosition();
				}
				TheMaxComputerGrade = 0;
				TheMaxPlayerGrade = 0;
				ball[m][n] = SimpleFrame.computerBall;
				mComputerLastBall = m;
				nComputerLastBall = n;
				computerChessCount++;
				MessageToShow = Message_Baby_you_go;
				checkIfTie();
				checkTableforComputer();
				if (!GameIsOver)
				{
					checkIfWhoWins();
				}
				IsPlayerTurn = true;
				IsComputerTurn = false;
				repaint();
				if (GameIsOver)
				{
					showGameOverInfomation();

				}
			}
	}

	public void countPlayerGrades()
	{
		for (i = 0; i <= (Boardsize - 1); i++)
			// COUNT playerGrades
			for (j = 0; j <= (Boardsize - 1); j++)
			{
				playerGrades[i][j] = 0;
				if (ball[i][j] == SimpleFrame.freeBall)
					for (k = 0; k < numberofwinpaths; k++)
						if (ptable[i][j][k])
						{
							switch (win[0][k])
							{
								case 1 :
									playerGrades[i][j] += GradeRank[0];
									break;
								case 2 :
									playerGrades[i][j] += GradeRank[1];
									break;
								case 3 :
									playerGrades[i][j] += GradeRank[2];
									break;
								case 4 :
									playerGrades[i][j] += GradeRank[3];
									break;
							}
						}
			}
	}
	public void countComputerGrades()
	{
		for (i = 0; i <= (Boardsize - 1); i++)
			// COUNT computerGrades
			for (j = 0; j <= (Boardsize - 1); j++)
			{
				computerGrades[i][j] = 0;
				if (ball[i][j] == SimpleFrame.freeBall)
					for (k = 0; k < numberofwinpaths; k++)
						if (ctable[i][j][k])
						{
							switch (win[1][k])
							{
								case 1 :
									computerGrades[i][j] += GradeRank[0];
									break;
								case 2 :
									computerGrades[i][j] += GradeRank[1];
									break;
								case 3 :
									computerGrades[i][j] += GradeRank[2];
									break;
								case 4 :
									computerGrades[i][j] += GradeRank[3];
									break;
							}
						}
			}
	}

	public static void checkBestPosition()
	{
		for (i = 0; i < Boardsize; i++)
			for (j = 0; j < Boardsize; j++)
				if (ball[i][j] == SimpleFrame.freeBall)
				{
					if (computerGrades[i][j] >= TheMaxComputerGrade)
					{
						TheMaxComputerGrade = computerGrades[i][j];
						mAttack = i;
						nAttack = j;
						// �Ե���������λ��
					}
					if (playerGrades[i][j] >= TheMaxPlayerGrade)
					{
						TheMaxPlayerGrade = playerGrades[i][j];
						mDefend = i;
						nDefend = j;
						// �����������λ��
					}
				}
		if (TheMaxPlayerGrade < TheMaxComputerGrade || TheMaxPlayerGrade <= littleGrade
				|| TheMaxComputerGrade >= bigGrade)
		{
			m = mAttack;// �Ե���������λ��
			n = nAttack;// �Ե���������λ��
		} else
		{
			m = mDefend;// �����������λ��
			n = nDefend;// �����������λ��
		}
		// if (TheMaxPlayerGrade >= TheMaxComputerGrade && TheMaxPlayerGrade >
		// 100
		// && TheMaxComputerGrade < 4000)
		// {
		// m = mDefend;//�����������λ��
		// n = nDefend;//�����������λ��
		// } else
		// {
		// m = mAttack;//�Ե���������λ��
		// n = nAttack;//�Ե���������λ��
		// }
	}

	public static void checkIfTie()
	{
		if ((computerChessCount == Boardsize*Boardsize/2) && (playerChessCount == Boardsize*Boardsize/2))
		{
			GameIsATie = true;
			GameIsOver = true;
			MessageToShow = Message_Baby_you_not_win;
		}
	}

	private void checkTableforPlayer()
	{
		for (i = 0; i < numberofwinpaths; i++)
		{
			/**
			 * ��(10*10) �� , ˫�� ֻ�� �� �� 192 ����� �л�ʤ
			 */
			/***
			 * ��� i ��� ���� ���(1��) and i ��� ���� ( 5�Ӵ��� )
			 * <p>
			 * ��ô�� �� i ������� (5�Ӵ���ĵط�)���(1 ��)
			 */
			if (ptable[m][n][i] && win[0][i] != impossible)
				win[0][i]++;
			/***
			 * ����� �� i ������� (5�Ӵ���ĵط�)���(5��)
			 * <p>
			 * ��ô ��ʤ
			 */
			/***
			 * ���(����)�� �� i ������� ���� ���(1��)
			 * <p>
			 * ���Ǳ�(���)����
			 * <p>
			 * ��ô (����)�� �� i ������� ���ٿ��� ���(1��)
			 * <p>
			 * ��ô (����)�� �� i ������� ���ٿ��� ���(5��)
			 */
			if (ctable[m][n][i])
			{
				ctable[m][n][i] = false;
				win[1][i] = impossible;
				// �� �� 1 ����� �в��ܻ�ʤ
			}
		}
	}
	private void checkTableforComputer()
	{
		for (i = 0; i < numberofwinpaths; i++)
		{
			if (ctable[m][n][i] && win[1][i] != impossible)
				win[1][i]++;
			if (ptable[m][n][i])
			{
				ptable[m][n][i] = false;
				win[0][i] = impossible;
			}
		}
	}

	public static int getxx(int th)
	{
		return (th - 400) / 2;
	}

	public static int getyy(int th)
	{
		return th - 400 - 5;
	}

	public static boolean MouseInTheBoard(int xMouse, int yMouse, int x, int y)
	{
		return xMouse > x && xMouse < (x + 400) && yMouse > y
				&& yMouse < (y + 400);
	}

	public static int getIndex(int Mouse, int x)
	{
		return (int) ((Mouse - x) / 40);
	}

	public static void soPlayerWins()
	{
		PlayerWinsTheGame = true;
		ComputerWinsTheGame = false;
		GameIsOver = true;
		MessageToShow = Message_Baby_you_good;
	}

	public static void soComputerWins()
	{
		ComputerWinsTheGame = true;
		PlayerWinsTheGame = false;
		GameIsOver = true;
		MessageToShow = Message_Baby_you_fool;
	}

	public static void showGameOverInfomation()
	{
		if (GameIsATie)
			JOptionPane
					.showConfirmDialog(null, "ƽ�֣�", "ȷ����Ϣ",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.INFORMATION_MESSAGE);
		else if (PlayerWinsTheGame)
			JOptionPane
					.showConfirmDialog(null, "��ϲ�㣡�����ˡ�", "ȷ����Ϣ",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.INFORMATION_MESSAGE);
		else if (ComputerWinsTheGame)
			JOptionPane
					.showConfirmDialog(null, "�����ˣ�", "ȷ����Ϣ",
							JOptionPane.DEFAULT_OPTION,
							JOptionPane.INFORMATION_MESSAGE);
	}

	public static void checkIfWhoWins()
	{
		for (i = 0; i <= 1; i++)
			for (j = 0; j < numberofwinpaths; j++)
			{
				if (win[i][j] == 5)
					if (i == 0)
					{
						soPlayerWins();
						break;
					} else
					{
						soComputerWins();
						break;
					}
				if (GameIsOver)
					break;
			}
	}

	public static void restart()
	{
		for (i = 0; i < Boardsize; i++)
			for (j = 0; j < Boardsize; j++)
			{
				playerGrades[i][j] = 0;
				computerGrades[i][j] = 0;
				ball[i][j] = SimpleFrame.freeBall;
			}
		count = 0;
		/**
		 * <b> ������Ļ����ϵ (1st,2nd)��ʾ (����ƫ����,����ƫ����)
		 * <p>
		 * �趨ˮƽ����Ļ�ʤλ�� ,���� 60 �� 5 ������
		 */
		for (i = 0; i <= Boardsize - 5; i++)

			for (j = 0; j < Boardsize; j++)
			{
				for (k = 0; k < 5; k++)
				{
					ptable[i + k][j + 0][count] = true;
					ctable[i + k][j + 0][count] = true;
					// ������չ
				}
				count++;
				// ÿ�� 5 ������ ռ�� 1 ��� count
			}

		/**
		 * <b> ������Ļ����ϵ (1st,2nd)��ʾ (����ƫ����,����ƫ����)
		 * <p>
		 * �趨��ֱ����Ļ�ʤλ�� ,���� 60 �� 5 ������
		 */
		for (i = 0; i < Boardsize; i++)
			// �趨��ֱ����Ļ�ʤλ��
			for (j = 0; j <= Boardsize - 5; j++)
			{
				for (k = 0; k < 5; k++)
				{
					ptable[i + 0][j + k][count] = true;
					ctable[i + 0][j + k][count] = true;
					// ������չ
				}
				count++;
				// ÿ�� 5 ������ ռ�� 1 ��� count
			}
		/**
		 * <b> ������Ļ����ϵ (1st,2nd)��ʾ (����ƫ����,����ƫ����)
		 * <p>
		 * �趨�Խ��߷���Ļ�ʤλ�� ,���� 36 �� 5 ������
		 */
		for (i = 0; i <= Boardsize - 5 ; i++)
			// �趨���Խ��߷���Ļ�ʤλ��
			for (j = 0; j <= Boardsize - 5; j++)
			{
				for (k = 0; k < 5; k++)
				{
					ptable[i + k][j + k][count] = true;
					ctable[i + k][j + k][count] = true;
					// ��������չ
				}
				count++;
				// ÿ�� 5 ������ ռ�� 1 ��� count
			}

		/**
		 * <b> ������Ļ����ϵ (1st,2nd)��ʾ (����ƫ����,����ƫ����)
		 * <p>
		 * �趨���Խ��߷���Ļ�ʤλ�� ,���� 36 �� 5 ������
		 */
		for (i = Boardsize - 1; i >= 5 - 1; i--)
			// �趨���Խ��߷���Ļ�ʤλ��
			for (j = 0; j <= Boardsize - 5; j++)
			{
				for (k = 0; k < 5; k++)
				{
					ptable[i - k][j + k][count] = true;
					ctable[i - k][j + k][count] = true;
					// ��������չ
				}
				count++;
				// ÿ�� 5 ������ ռ�� 1 ��� count
			}

		for (i = 0; i <= 1; i++)
			for (j = 0; j < numberofwinpaths; j++)
				win[i][j] = 0;
		IsComputerTurn = false;
		IsPlayerTurn = true;
		MessageToShow = Message_Baby_you_first;
		count = 0;
		computerChessCount = 0;
		playerChessCount = 0;
		GameJustStarted = true;
		GameIsOver = false;
		PlayerWinsTheGame = false;
		ComputerWinsTheGame = false;
		GameIsATie = false;
		mComputerLastBall = SimpleFrame.OUT_OF_FRAME;
		nComputerLastBall = SimpleFrame.OUT_OF_FRAME;
	}

	// MouseMotion
	private class MouseMotionHandler implements MouseMotionListener
	{
		public void mouseMoved(MouseEvent event)
		{
			xMouse = event.getX();
			yMouse = event.getY();
			repaint();
		}

		public void mouseDragged(MouseEvent event)
		{
		}
	}

	private class MouseHandler extends MouseAdapter
	{
		public void mousePressed(MouseEvent event)
		{
			playerdo(event);
		}
	}

	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		int FrameWidth = getWidth();
		int FrameHeight = getHeight();
		int x = (FrameWidth - 400) / 2;
		int y = FrameHeight - 400;
		int px = xMouse - (xMouse - x) % 40;
		int py = yMouse - (yMouse - y) % 40;
		if (px < x)
			px = x;
		if (py < y)
			py = y;
		if (px > (x + 360))
			px = x + 360;
		if (py > (y + 360))
			py = y + 360;
		g.drawImage(image, x, y, null);
		g.drawImage(position, px, py, null);
		Font f = new Font("����_GB2312", Font.BOLD, 20);
		g.setFont(f);
		g.setColor(new Color(204, 66, 204));
		g.drawString("�����", 5, 60);
		g.setColor(new Color(00, 99, 00));
		g.drawString(" �� ��", 5, 260);
		g.drawImage(red, 20, 75, null);
		g.drawImage(green, 20, 275, null);
		g.setColor(Color.black);
		switch (MessageToShow)
		{
			case 0 :
				g.drawString("������!", 240, 40);
				break;
			case 1 :
				g.drawString("�ȴ�!", 240, 40);
				break;
			case 2 :
				g.drawString("����ѽ.", 240, 40);
				break;
			case 3 :
				g.drawString("��������", 240, 40);
				break;
			case 4 :
				g.drawString("����ЦЦ!", 240, 40);
				break;
			case 5 :
				g.drawString("ƽ ��!", 240, 140);
				break;
		}
		for (i = 0; i < Boardsize; i++)
			for (j = 0; j < Boardsize; j++)
			{
				if (ball[i][j] == SimpleFrame.playerBall)
				{
					px = i * 40 + 3 + x;
					py = j * 40 + 3 + y;
					g.drawImage(green, px, py, null);
				}
				if (ball[i][j] == SimpleFrame.computerBall)
				{
					px = i * 40 + 3 + x;
					py = j * 40 + 3 + y;
					g.drawImage(red, px, py, null);
				}
			}
		g.drawImage(ired, mComputerLastBall * 40 + x + 3, nComputerLastBall
				* 40 + y + 3, null);
	}
	public ImagePanel()
	{
		image = Toolkit.getDefaultToolkit().getImage(
				ImagePanel.class.getResource("image/map.gif"));
		green = Toolkit.getDefaultToolkit().getImage(
				ImagePanel.class.getResource("image/green.gif"));
		red = Toolkit.getDefaultToolkit().getImage(
				ImagePanel.class.getResource("image/red.gif"));
		position = Toolkit.getDefaultToolkit().getImage(
				ImagePanel.class.getResource("image/position.gif"));
		ired = Toolkit.getDefaultToolkit().getImage(
				ImagePanel.class.getResource("image/ired.gif"));
		addMouseListener(new MouseHandler());
		addMouseMotionListener(new MouseMotionHandler());
		MediaTracker tracker = new MediaTracker(this);

		tracker.addImage(image, 1); // board
		tracker.addImage(green, 2); // green
		tracker.addImage(red, 3); // red
		tracker.addImage(position, 4); // position
		tracker.addImage(ired, 5);
		try
		{
			tracker.waitForID(1);
			tracker.waitForID(2);
			tracker.waitForID(3);
			tracker.waitForID(4);
			tracker.waitForID(5);
		} catch (InterruptedException exception)
		{
		}

		restart();
	}

	/**
	 * @return the boardsize
	 */
	public int getBoardsize()
	{
		return Boardsize;
	}

	/**
	 * @param boardsize
	 *            the boardsize to set
	 */
	public void setBoardsize(int boardsize)
	{
		Boardsize = boardsize;
		numberofwinpaths = 2 * Boardsize * (Boardsize - 5) + 2
				* (Boardsize - 5) * (Boardsize - 5);
	}
}