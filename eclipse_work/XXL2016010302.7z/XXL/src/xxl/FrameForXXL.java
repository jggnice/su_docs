package xxl;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class FrameForXXL extends JFrame
{

	/**
	 * <b>Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable() {
			public void run()
			{
				try
				{
					FrameForXXL frame = new FrameForXXL();
					frame.setVisible(true);
					MusicForXXL.playbgm();
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * <b>Create the frame.
	 */
	public FrameForXXL()
	{
		System.out.println("******console log for XXL********");
		System.out.println("******���������ֵĿ���̨���********");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(148, 72, 675, 534);
		contentPane = new JPanel();
		contentPane.setOpaque(true);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		xiaoxiao = new PanelForXXL();
		xiaoxiao.setOpaque(false);
		contentPane.add(xiaoxiao);

		panel = new JPanel();
		contentPane.add(panel, BorderLayout.WEST);
		panel.setLayout(new GridLayout(0, 1, 0, 0));

		btnCheck = new JButton("check");
		btnCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0)
			{
				xiaoxiao.checkAll();
			}
		});
		panel.add(btnCheck);

		btnClear = new JButton("clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0)
			{
				xiaoxiao.clearAll();
			}
		});
		panel.add(btnClear);

		JButton btnAction = new JButton("Action");
		panel.add(btnAction);

		JPanel panel_1 = new JPanel();
		contentPane.add(panel_1, BorderLayout.EAST);
		panel_1.setLayout(new GridLayout(0, 1, 0, 0));

		JButton btnNewgame = new JButton("newGame");
		panel_1.add(btnNewgame);

		JButton btnPause = new JButton("pause");
		btnPause.addMouseListener(new MouseAdapter() {

		});
		panel_1.add(btnPause);

		JCheckBox chckbxMusic = new JCheckBox("music");
		panel_1.add(chckbxMusic);
		btnAction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0)
			{
				xiaoxiao.dropAll();
			}
		});

		/*
		 * Toolkit tk = Toolkit.getDefaultToolkit(); Image image = new
		 * ImageIcon(PIC.mousepoint).getImage(); Cursor cursor =
		 * tk.createCustomCursor(image, new Point(10, 10), "norm");
		 * this.setCursor(cursor); // panel Ҳ�������������
		 */}
	private static final long serialVersionUID = 9059115948870291404L;
	private JPanel contentPane;
	PanelForXXL xiaoxiao;
	private JPanel panel;
	private JButton btnCheck;
	private JButton btnClear;
}
