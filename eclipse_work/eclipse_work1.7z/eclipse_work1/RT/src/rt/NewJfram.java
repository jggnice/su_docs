
package rt;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.GridLayout;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
@SuppressWarnings("serial")
public class NewJfram extends JFrame 
{	//variable declarations
	private  JPanel contentPane=new JPanel();
	
	private   JButton button;

	private static JButton button_1;

	private static JButton button_2;

	private static JButton button_3;

	private static JButton button_4;

	private static JButton button_5;

	private static JButton button_6;

	private static JButton button_7;

	private static JButton button_8;
	
	/**
	 * Create the frame.
	 */

	public NewJfram() 
	{

		//default options
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 414);
		//contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 3, 0, 0));
		
		//add buttons
		button.setText("rt");
		contentPane.add(button);
		contentPane.add(button_1);contentPane.add(button_2);
		contentPane.add(button_3);contentPane.add(button_4);contentPane.add(button_5);
		contentPane.add(button_6);contentPane.add(button_7);contentPane.add(button_8);
		//Initial buttons
		Initialbuttons();
		//register listeners
		Registerlisteners();		
		
	}

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewJfram frame = new NewJfram();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public static void Initialbuttons()
	{
		int[] numbers={0,0,0,0,0,0,0,0,0};
		boolean[] flags={false,false,false,false,false,false,false,false,false};
		int tep,tep1;
		int count=0;
//count random numbers
		while(count<9)
		{
			tep=(int)(Math.random()*9);
			if(flags[tep]==false){flags[tep]=true;numbers[count]=tep+1;count++;}
		}
//count reverse numbers
		count=0;
		for(tep=0;tep<8;tep++)
		for(tep1=tep+1;tep1<9;tep1++)
		{
			if((numbers[tep]>numbers[tep1])&&(numbers[tep]!=9)&&(numbers[tep1]!=9))
				count++;
		}
		
		System.out.println(count);
//make  reverse numbers even
		if(count%2==1)
		{	int i=0;
			int select1=0,select2=1;
			while(numbers[i]==9){i++;} select1=i;i++;
			while(numbers[i]==9){i++;} select2=i;
			tep=numbers[select1];numbers[select1]=numbers[select2];numbers[select2]=tep;
		}
//count reverse numbers
		count=0;
		for(tep=0;tep<8;tep++)
		for(tep1=tep+1;tep1<9;tep1++)
		{
			if((numbers[tep]>numbers[tep1])&&(numbers[tep]!=9)&&(numbers[tep1]!=9))
				count++;
		}
		System.out.println(count);
		
		button.setText(""+numbers[0]);if(button.getText().equals("9"))button.setText("    ");		
		button_1.setText(""+numbers[1]);if(button_1.getText().equals("9"))button_1.setText("    ");
		button_2.setText(""+numbers[2]);if(button_2.getText().equals("9"))button_2.setText("    ");
		button_3.setText(""+numbers[3]);if(button_3.getText().equals("9"))button_3.setText("    ");
		button_4.setText(""+numbers[4]);if(button_4.getText().equals("9"))button_4.setText("    ");
		button_5.setText(""+numbers[5]);if(button_5.getText().equals("9"))button_5.setText("    ");
		button_6.setText(""+numbers[6]);if(button_6.getText().equals("9"))button_6.setText("    ");
		button_7.setText(""+numbers[7]);if(button_7.getText().equals("9"))button_7.setText("    ");
		button_8.setText(""+numbers[8]);if(button_8.getText().equals("9"))button_8.setText("    ");
		
	}
	/*
	public void Figureflag()
	{
		if(button.getText()!="1"||button_1.getText()!="2"||button_2.getText()!="3"||button_3.getText()!="4"||button_4.getText()!="5"||button_5.getText()!="6"||button_6.getText()!="7"||button_7.getText()!="8")
		{
			Newgame dialog1 = new Newgame();
			dialog1.setVisible(true);
		}
	}
	*/
	public void Registerlisteners()
	{

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//button.setText("hello");
				    if("    ".equals(button_1.getText()))
			        {
			            button_1.setText(button.getText());
			            button.setText("    ");
			        }
			        if("    ".equals(button_3.getText()))
			        {
			            button_3.setText(button.getText());
			            button.setText("    ");
			        }
			        //Figureflag();
			}
		});
		
		
		
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 if("    ".equals(button.getText()))
			        {
			            button.setText(button_1.getText());
			            button_1.setText("    ");
			        }
			        if("    ".equals(button_2.getText()))
			        {
			            button_2.setText(button_1.getText());
			            button_1.setText("    ");
			        }
			        if("    ".equals(button_4.getText()))
			        {
			            button_4.setText(button_1.getText());
			            button_1.setText("    ");
			        }
			        //Figureflag();			
			        }
		});
		
		
	
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 if("    ".equals(button_1.getText()))
			        {
			            button_1.setText(button_2.getText());
			            button_2.setText("    ");
			        }
			        if("    ".equals(button_5.getText()))
			        {
			            button_5.setText(button_2.getText());
			            button_2.setText("    ");
			        }
			        //Figureflag();
			}
		});
		
		
		
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 if("    ".equals(button.getText()))
			        {
			            button.setText(button_3.getText());
			            button_3.setText("    ");
			        }
			        if("    ".equals(button_4.getText()))
			        {
			            button_4.setText(button_3.getText());
			            button_3.setText("    ");
			        }
			        if("    ".equals(button_6.getText()))
			        {
			            button_6.setText(button_3.getText());
			            button_3.setText("    ");
			        }
			        //Figureflag();
			}
		});
		
		
		
		 button_4.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_1.getText()))
		         {
		             button_1.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         if("    ".equals(button_3.getText()))
		         {
		             button_3.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         if("    ".equals(button_5.getText()))
		         {
		             button_5.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         if("    ".equals(button_7.getText()))
		         {
		             button_7.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         //Figureflag();
		 	}
		 });
		
		
		
		 button_5.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_8.getText()))
		         {
		             button_8.setText(button_5.getText());
		             button_5.setText("    ");
		         }
		         if("    ".equals(button_4.getText()))
		         {
		             button_4.setText(button_5.getText());
		             button_5.setText("    ");
		         }
		         if("    ".equals(button_2.getText()))
		         {
		             button_2.setText(button_5.getText());
		             button_5.setText("    ");
		         }
		         //Figureflag();
		 	}
		 });
		
		
		
		 button_6.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_7.getText()))
		         {
		             button_7.setText(button_6.getText());
		             button_6.setText("    ");
		         }
		         if("    ".equals(button_3.getText()))
		         {
		             button_3.setText(button_6.getText());
		             button_6.setText("    ");
		         }
		         //Figureflag();
		 	}
		 });
		
		
		 button_7.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_8.getText()))
		         {
		             button_8.setText(button_7.getText());
		             button_7.setText("    ");
		         }
		         if("    ".equals(button_4.getText()))
		         {
		             button_4.setText(button_7.getText());
		             button_7.setText("    ");
		         }
		         if("    ".equals(button_6.getText()))
		         {
		             button_6.setText(button_7.getText());
		             button_7.setText("    ");
		         }
		         //Figureflag();
		 	}
		 });
		
		
		
		 button_8.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_5.getText()))
		         {
		             button_5.setText(button_8.getText());
		             button_8.setText("    ");
		         }
		         if("    ".equals(button_7.getText()))
		         {
		             button_7.setText(button_8.getText());
		             button_8.setText("    ");
		         }
		         //Figureflag();
		 	}
		 });
		
	}

}
