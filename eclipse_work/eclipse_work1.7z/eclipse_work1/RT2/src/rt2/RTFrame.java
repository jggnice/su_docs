package rt2;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JLabel;

public class RTFrame extends JFrame {

	private JPanel contentPane;
	private JTextField txtTimeToBe;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					RTFrame frame = new RTFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public RTFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_1 = new JPanel();
		panel.add(panel_1, BorderLayout.CENTER);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JPanel panel_2 = new JPanel();
		panel_1.add(panel_2, BorderLayout.CENTER);
		panel_2.setLayout(new BorderLayout(0, 0));
		
		txtTimeToBe = new JTextField();
		txtTimeToBe.setFont(new Font("SimSun", Font.PLAIN, 22));
		txtTimeToBe.setText("Time to be displayed here");
		panel_2.add(txtTimeToBe, BorderLayout.NORTH);
		txtTimeToBe.setColumns(10);
		
		JPanel panel_3 = new JPanel();
		panel_2.add(panel_3, BorderLayout.CENTER);
		panel_3.setLayout(new GridLayout(0, 3, 0, 0));
		
		JButton button_0 = new JButton("1");
		panel_3.add(button_0);
		
		JButton button_1 = new JButton("2");
		panel_3.add(button_1);
		
		JButton button_2 = new JButton("3");
		panel_3.add(button_2);
		
		JButton button_3 = new JButton("4");
		panel_3.add(button_3);
		
		JButton button_4 = new JButton("5");
		panel_3.add(button_4);
		
		JButton button_5 = new JButton("6");
		panel_3.add(button_5);
		
		JButton button = new JButton("7");
		panel_3.add(button);
		
		JButton button_6 = new JButton("8");
		panel_3.add(button_6);
		
		JButton button_7 = new JButton("9");
		panel_3.add(button_7);
		
		JButton button_8 = new JButton("0");
		panel_3.add(button_8);
		
		JButton btnStart = new JButton("Start");
		panel_3.add(btnStart);
		
		JButton btnStop = new JButton("Stop");
		panel_3.add(btnStop);
		
		JPanel panel_4 = new JPanel();
		panel.add(panel_4, BorderLayout.WEST);
		panel_4.setLayout(new GridLayout(0, 1, 0, 0));
		
		JButton btnB = new JButton("b0");
		btnB.setIcon(new ImageIcon("image/introvj6.jpg"));
		btnB.setFont(new Font("SimSun", Font.PLAIN, 36));
		panel_4.add(btnB);
		
		JLabel lblF = new JLabel(" ");
		lblF.setIcon(new ImageIcon("image/intro1e.gif"));
		panel_4.add(lblF);
	}

}
