/**
 * 
 */
package rt2;

/**
 * @author ��
 *
 */
public class main1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
