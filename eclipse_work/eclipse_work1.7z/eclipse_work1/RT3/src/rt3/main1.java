package rt3;

public class main1 {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rt3Frame f1=new Rt3Frame();
		f1.setVisible(true);

	}

}
