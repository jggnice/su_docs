package rt3_1;

import javax.swing.JApplet;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class Applet1 extends JApplet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/*
	 Launch the application.
	
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewJfram frame = new NewJfram();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	});*/
	

	/**
	 * Create the frame.
	 */
	public Applet1() {
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//setBounds(100, 100, 450, 414);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 3, 0, 0));
		
		int[] numbers={0,0,0,0,0,0,0,0,0};
		boolean[] flags={false,false,false,false,false,false,false,false,false};
		int tep,tep1;
		int count=0;
		while(count<9)
		{
			tep=(int)(Math.random()*9);
			if(flags[tep]==false){flags[tep]=true;numbers[count]=tep+1;count++;}
		}
		count=0;
		for(tep=0;tep<8;tep++)
		for(tep1=tep+1;tep1<9;tep1++)
		{
			if((numbers[tep]>numbers[tep1])&&(numbers[tep]!=9)&&(numbers[tep1]!=9))
				count++;
		}
		
		System.out.println(count);
		if(count%2==1)
		{	int i=0;
			int select1=0,select2=1;
			while(numbers[i++]==9); select1=i;
			while(numbers[i++]==9); select2=i;
			tep=numbers[select1];numbers[select1]=numbers[select2];numbers[select2]=tep;
		}
		count=0;
		for(tep=0;tep<8;tep++)
		for(tep1=tep+1;tep1<9;tep1++)
		{
			if((numbers[tep]>numbers[tep1])&&(numbers[tep]!=9)&&(numbers[tep1]!=9))
				count++;
		}
		System.out.println(count);
		
		JButton button, button_1, button_2, button_3, button_4, button_5, button_6, button_7, button_8;
		button   = new JButton(""+numbers[0]);contentPane.add(button);if(button.getText().equals("9"))button.setText("    ");
		//button.setFont(new Font("SimSun", Font.PLAIN, 16));
		button_1 = new JButton(""+numbers[1]);contentPane.add(button_1);if(button_1.getText().equals("9"))button_1.setText("    ");
		button_2 = new JButton(""+numbers[2]);contentPane.add(button_2);if(button_2.getText().equals("9"))button_2.setText("    ");
		button_3 = new JButton(""+numbers[3]);contentPane.add(button_3);if(button_3.getText().equals("9"))button_3.setText("    ");
		button_4 = new JButton(""+numbers[4]);contentPane.add(button_4);if(button_4.getText().equals("9"))button_4.setText("    ");
		button_5 = new JButton(""+numbers[5]);contentPane.add(button_5);if(button_5.getText().equals("9"))button_5.setText("    ");
		button_6 = new JButton(""+numbers[6]);contentPane.add(button_6);if(button_6.getText().equals("9"))button_6.setText("    ");
		button_7 = new JButton(""+numbers[7]);contentPane.add(button_7);if(button_7.getText().equals("9"))button_7.setText("    ");
		button_8 = new JButton(""+numbers[8]);contentPane.add(button_8);if(button_8.getText().equals("9"))button_8.setText("    ");
		
		
		
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//button.setText("hello");
				 if("    ".equals(button_1.getText()))
			        {
			            button_1.setText(button.getText());
			            button.setText("    ");
			        }
			        if("    ".equals(button_3.getText()))
			        {
			            button_3.setText(button.getText());
			            button.setText("    ");
			        }
			}
		});
		
		
		
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 if("    ".equals(button.getText()))
			        {
			            button.setText(button_1.getText());
			            button_1.setText("    ");
			        }
			        if("    ".equals(button_2.getText()))
			        {
			            button_2.setText(button_1.getText());
			            button_1.setText("    ");
			        }
			        if("    ".equals(button_4.getText()))
			        {
			            button_4.setText(button_1.getText());
			            button_1.setText("    ");
			        }
			}
		});
		
		
	
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 if("    ".equals(button_1.getText()))
			        {
			            button_1.setText(button_2.getText());
			            button_2.setText("    ");
			        }
			        if("    ".equals(button_5.getText()))
			        {
			            button_5.setText(button_2.getText());
			            button_2.setText("    ");
			        }
			}
		});
		
		
		
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 if("    ".equals(button.getText()))
			        {
			            button.setText(button_3.getText());
			            button_3.setText("    ");
			        }
			        if("    ".equals(button_4.getText()))
			        {
			            button_4.setText(button_3.getText());
			            button_3.setText("    ");
			        }
			        if("    ".equals(button_6.getText()))
			        {
			            button_6.setText(button_3.getText());
			            button_3.setText("    ");
			        }
			}
		});
		
		
		
		 button_4.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_1.getText()))
		         {
		             button_1.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         if("    ".equals(button_3.getText()))
		         {
		             button_3.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         if("    ".equals(button_5.getText()))
		         {
		             button_5.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         if("    ".equals(button_7.getText()))
		         {
		             button_7.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		 	}
		 });
		
		
		
		 button_5.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_8.getText()))
		         {
		             button_8.setText(button_5.getText());
		             button_5.setText("    ");
		         }
		         if("    ".equals(button_4.getText()))
		         {
		             button_4.setText(button_5.getText());
		             button_5.setText("    ");
		         }
		         if("    ".equals(button_2.getText()))
		         {
		             button_2.setText(button_5.getText());
		             button_5.setText("    ");
		         }
		 	}
		 });
		
		
		
		 button_6.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_7.getText()))
		         {
		             button_7.setText(button_6.getText());
		             button_6.setText("    ");
		         }
		         if("    ".equals(button_3.getText()))
		         {
		             button_3.setText(button_6.getText());
		             button_6.setText("    ");
		         }
		 	}
		 });
		
		
		 button_7.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_8.getText()))
		         {
		             button_8.setText(button_7.getText());
		             button_7.setText("    ");
		         }
		         if("    ".equals(button_4.getText()))
		         {
		             button_4.setText(button_7.getText());
		             button_7.setText("    ");
		         }
		         if("    ".equals(button_6.getText()))
		         {
		             button_6.setText(button_7.getText());
		             button_7.setText("    ");
		         }
		 	}
		 });
		
		
		
		 button_8.addActionListener(new ActionListener() {
		 	public void actionPerformed(ActionEvent arg0) {
		 		 if("    ".equals(button_5.getText()))
		         {
		             button_5.setText(button_8.getText());
		             button_8.setText("    ");
		         }
		         if("    ".equals(button_7.getText()))
		         {
		             button_7.setText(button_8.getText());
		             button_8.setText("    ");
		         }
		 	}
		 });
		
	}

}

