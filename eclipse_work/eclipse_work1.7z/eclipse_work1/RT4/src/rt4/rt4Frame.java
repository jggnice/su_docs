package rt4;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JToolBar;
import javax.swing.JInternalFrame;
import javax.swing.JDesktopPane;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JRadioButton;
import javax.swing.JToggleButton;
import javax.swing.ButtonGroup;
import java.awt.GridLayout;
import javax.swing.JFormattedTextField;
import javax.swing.DropMode;
import java.awt.FlowLayout;
import javax.swing.JPasswordField;
import javax.swing.JTextPane;
import javax.swing.JEditorPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerListModel;
import javax.swing.JList;
import javax.swing.AbstractListModel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.JScrollBar;
import javax.swing.JSlider;

public class rt4Frame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	private JPasswordField pwdHowDoYou;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					rt4Frame frame = new rt4Frame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public rt4Frame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 661, 528);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JTabbedPane tabbedPane_1 = new JTabbedPane(JTabbedPane.TOP);
		contentPane.add(tabbedPane_1, BorderLayout.CENTER);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.BOTTOM);
		tabbedPane_1.addTab("20", null, tabbedPane, null);
		tabbedPane.setToolTipText("good");
		
		JLabel label = new JLabel("\u597D");
		tabbedPane.addTab("a", null, label, null);
		label.setFont(new Font("SimSun", Font.PLAIN, 34));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel label_1 = new JLabel("\u8FD0");
		tabbedPane.addTab("b", null, label_1, null);
		label_1.setHorizontalAlignment(SwingConstants.CENTER);
		label_1.setFont(new Font("SimSun", Font.PLAIN, 34));
		
		JLabel label_2 = new JLabel("\u6765");
		tabbedPane.addTab("c", null, label_2, null);
		label_2.setHorizontalAlignment(SwingConstants.CENTER);
		label_2.setFont(new Font("SimSun", Font.PLAIN, 34));
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("\u597D", null, panel_1, null);
		tabbedPane.setEnabledAt(3, true);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JRadioButton rdbtnTy = new JRadioButton("ty");
		panel_1.add(rdbtnTy, BorderLayout.NORTH);
		
		JRadioButton rdbtnHy = new JRadioButton("hy");
		panel_1.add(rdbtnHy, BorderLayout.SOUTH);
		
		JToggleButton tglbtnIs = new JToggleButton("is_1");
		tglbtnIs.setSelected(true);
		panel_1.add(tglbtnIs, BorderLayout.EAST);
		
		JPanel panel_7 = new JPanel();
		panel_1.add(panel_7, BorderLayout.CENTER);
		panel_7.setLayout(new GridLayout(0, 3, 0, 0));
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("1");
		buttonGroup.add(rdbtnNewRadioButton_1);
		panel_7.add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("2");
		buttonGroup.add(rdbtnNewRadioButton);
		panel_7.add(rdbtnNewRadioButton);
		
		JRadioButton radioButton = new JRadioButton("3");
		buttonGroup.add(radioButton);
		panel_7.add(radioButton);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("4");
		buttonGroup_1.add(rdbtnNewRadioButton_2);
		panel_7.add(rdbtnNewRadioButton_2);
		
		JRadioButton rdbtnNewRadioButton_3 = new JRadioButton("5");
		buttonGroup_1.add(rdbtnNewRadioButton_3);
		panel_7.add(rdbtnNewRadioButton_3);
		
		JRadioButton radioButton_1 = new JRadioButton("6");
		buttonGroup_1.add(radioButton_1);
		panel_7.add(radioButton_1);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("\u8FD0", null, panel_2, null);
		panel_2.setLayout(new GridLayout(0, 1, 0, 0));
		
		JFormattedTextField frmtdtxtfldHow = new JFormattedTextField();
		frmtdtxtfldHow.setDropMode(DropMode.INSERT);
		frmtdtxtfldHow.setText("how");
		panel_2.add(frmtdtxtfldHow);
		
		pwdHowDoYou = new JPasswordField();
		pwdHowDoYou.setText("how do you know");
		panel_2.add(pwdHowDoYou);
		
		JTextPane txtpnWhenIWas = new JTextPane();
		txtpnWhenIWas.setFont(new Font("Simsun (Founder Extended)", Font.BOLD | Font.ITALIC, 18));
		txtpnWhenIWas.setText("when i was young i'd like to listen to the radio");
		panel_2.add(txtpnWhenIWas);
		
		JEditorPane dtrpnWhatAreYou = new JEditorPane();
		dtrpnWhatAreYou.setText("what are you thinking");
		panel_2.add(dtrpnWhatAreYou);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerListModel(new String[] {"q1", "q2", "q3", "q4", "q5", "q6"}));
		panel_2.add(spinner);
		
		JScrollPane scrollPane = new JScrollPane();
		panel_2.add(scrollPane);
		
		JList list = new JList();
		list.setModel(new AbstractListModel() {
			String[] values = new String[] {"w1", "w2", "w3", "w4", "w5", "w6", "e1", "e2", "e3", "e4", "r1", "r2", "r3", "r4", "a1", "a2", "a3", "a4"};
			public int getSize() {
				return values.length;
			}
			public Object getElementAt(int index) {
				return values[index];
			}
		});
		scrollPane.setViewportView(list);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("\u6765", null, panel_3, null);
		panel_3.setLayout(new BorderLayout(0, 0));
		
		JButton btnW = new JButton("w");
		panel_3.add(btnW, BorderLayout.SOUTH);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"ffef", "cdc", null},
				{null, null, "cdd"},
				{null, null, "vd"},
			},
			new String[] {
				"New column", "New column", "New column"
			}
		));
		table.setBackground(Color.ORANGE);
		table.setFillsViewportHeight(true);
		table.setColumnSelectionAllowed(true);
		table.setCellSelectionEnabled(true);
		panel_3.add(table, BorderLayout.WEST);
		
		JScrollBar scrollBar = new JScrollBar();
		panel_3.add(scrollBar, BorderLayout.CENTER);
		
		JSlider slider = new JSlider();
		panel_3.add(slider, BorderLayout.NORTH);
		
		JTabbedPane tabbedPane_2 = new JTabbedPane(JTabbedPane.RIGHT);
		tabbedPane_1.addTab("30", null, tabbedPane_2, null);
		
		JPanel panel = new JPanel();
		tabbedPane_2.addTab("31", null, panel, null);
		panel.setLayout(new BorderLayout(0, 0));
		
		JToolBar toolBar = new JToolBar();
		toolBar.setRollover(true);
		panel.add(toolBar, BorderLayout.NORTH);
		
		JButton btnNewButton = new JButton("New button");
		toolBar.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("New button");
		toolBar.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("New button");
		toolBar.add(btnNewButton_2);
		
		JInternalFrame internalFrame = new JInternalFrame("New JInternalFrame");
		panel.add(internalFrame, BorderLayout.CENTER);
		
		JTabbedPane tabbedPane_3 = new JTabbedPane(JTabbedPane.TOP);
		internalFrame.getContentPane().add(tabbedPane_3, BorderLayout.CENTER);
		
		JPanel panel_4 = new JPanel();
		tabbedPane_3.addTab("New tab", null, panel_4, null);
		
		JPanel panel_5 = new JPanel();
		tabbedPane_3.addTab("New tab", null, panel_5, null);
		
		JPanel panel_6 = new JPanel();
		tabbedPane_2.addTab("32", null, panel_6, null);
		panel_6.setLayout(new BorderLayout(0, 0));
		
		JDesktopPane desktopPane = new JDesktopPane();
		panel_6.add(desktopPane, BorderLayout.CENTER);
		
		JButton btnNewButton_3 = new JButton("New button");
		btnNewButton_3.setBounds(463, 55, 105, 25);
		desktopPane.add(btnNewButton_3);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setForeground(Color.RED);
		lblNewLabel.setBackground(Color.ORANGE);
		lblNewLabel.setBounds(63, 64, 63, 16);
		desktopPane.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(140, 61, 76, 22);
		desktopPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(63, 114, 63, 16);
		desktopPane.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(140, 111, 76, 22);
		desktopPane.add(textField_1);
		textField_1.setColumns(10);
		
		JCheckBox chckbxBold = new JCheckBox("bold");
		chckbxBold.setBounds(63, 171, 117, 25);
		desktopPane.add(chckbxBold);
		
		JCheckBox chckbxItalian = new JCheckBox("Italian");
		chckbxItalian.setBounds(63, 225, 117, 25);
		desktopPane.add(chckbxItalian);
		
		JCheckBox chckbxBig = new JCheckBox("BIG");
		chckbxBig.setBounds(63, 279, 117, 25);
		desktopPane.add(chckbxBig);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setEditable(true);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"fgrg", "htht"}));
		comboBox.setBounds(216, 91, 352, 339);
		desktopPane.add(comboBox);
		internalFrame.setVisible(true);
	}
}
