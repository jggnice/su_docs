package org.liky.game.frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class FiveChessFrame extends JFrame implements MouseListener, Runnable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// width
	int width = Toolkit.getDefaultToolkit().getScreenSize().width;

	// height
	int height = Toolkit.getDefaultToolkit().getScreenSize().height;

	// background
	BufferedImage bgImage = null;
	
	
	// chess point
	int x = 0;
	int y = 0;
	// save all chess
	//  0:no chess  1:black chess 2:white chess
	int[][] allChess = new int[19][19];
	// who first
	boolean isBlack = true;
	// canPlay flag
	boolean canPlay = true;
	// tip info
	String message = "black first";
	// time remained (seconds)
	int maxTime = 0;
	// Thread of Timer
	Thread t = new Thread(this);
	// time remained 
	int blackTime = 0;
	int whiteTime = 0;
	// time remained 
	String blackMessage = "limitiless";
	String whiteMessage = "limitiless";

	@SuppressWarnings("deprecation")
	public FiveChessFrame() {
		// title
		this.setTitle("FiveChessGame");
		// window size
		this.setSize(500, 500);
		// window position
		this.setLocation((width - 500) / 2, (height - 500) / 2);
		// can't resize
		this.setResizable(false);
		// exit action 
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// listener
		this.addMouseListener(this);
		this.setVisible(true);
		
		try 
		{
			bgImage = ImageIO.read(new File("src/org/liky/image/background.jpg"));
		} 
		catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		t.start();
		t.suspend();

		// refresh
		this.repaint();
		
//*********************************************************************************************
		
	}

	public void paint(Graphics g) {
		//no flash
		BufferedImage bi = new BufferedImage(500, 500,
				BufferedImage.TYPE_INT_RGB);
		Graphics g2 = bi.createGraphics();
		g2.setColor(Color.BLACK);
		// background
		g2.drawImage(bgImage, 1, 20, this);
		// title info
		g2.setFont(new Font("����", Font.BOLD, 20));
		g2.drawString("game info" + message, 130, 60);
		// time information
		g2.setFont(new Font("����", 0, 14));
		g2.drawString("time for black:" + blackMessage, 30, 470);
		g2.drawString("time for white:" + whiteMessage, 260, 470);

		// chess board
		for (int i = 0; i < 19; i++) {
			g2.drawLine(10, 70 + 20 * i, 370, 70 + 20 * i);
			g2.drawLine(10 + 20 * i, 70, 10 + 20 * i, 430);
		}

		//9 point position
		g2.fillOval(66, 126, 8, 8);
		g2.fillOval(306, 126, 8, 8);
		g2.fillOval(306, 366, 8, 8);
		g2.fillOval(66, 366, 8, 8);
		g2.fillOval(306, 246, 8, 8);
		g2.fillOval(186, 126, 8, 8);
		g2.fillOval(66, 246, 8, 8);
		g2.fillOval(186, 366, 8, 8);
		g2.fillOval(186, 246, 8, 8);

	

		// paint all chesses
		for (int i = 0; i < 19; i++) {
			for (int j = 0; j < 19; j++) {
				if (allChess[i][j] == 1) {
					// ����
					int tempX = i * 20 + 10;
					int tempY = j * 20 + 70;
					g2.fillOval(tempX - 7, tempY - 7, 14, 14);
				}
				if (allChess[i][j] == 2) {
					// ����
					int tempX = i * 20 + 10;
					int tempY = j * 20 + 70;
					g2.setColor(Color.WHITE);
					g2.fillOval(tempX - 7, tempY - 7, 14, 14);
					g2.setColor(Color.BLACK);
					g2.drawOval(tempX - 7, tempY - 7, 14, 14);
				}
			}
		}
		g.drawImage(bi, 0, 0, this);
	}

	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
	
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}	
	

	@SuppressWarnings("deprecation")
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		/*
		 * System.out.println("X:"+e.getX()); System.out.println("Y:"+e.getY());
		 */
		if (canPlay == true) {
			x = e.getX();
			y = e.getY();
			if (x >= 10 && x <= 370 && y >= 70 && y <= 430) {
				x = (x - 1) / 20;
				y = (y - 61) / 20;
				if (allChess[x][y] == 0) {
					// who run
					if (isBlack == true) {
						allChess[x][y] = 1;
						isBlack = false;
						message = "__now white";
					} else {
						allChess[x][y] = 2;
						isBlack = true;
						message = "__now black";
					}
					// win ?
					boolean winFlag = this.checkWin();
					if (winFlag == true) {
						JOptionPane.showMessageDialog(this, "game over,"
								+ (allChess[x][y] == 1 ? "black" : "white") + "wins!");
						canPlay = false;
					}
				}
				
				
				this.repaint();
			}
		}
		/* System.out.println(e.getX() + " -- " + e.getY()); */
		//start
		if (e.getX() >= 400 && e.getX() <= 470 && e.getY() >= 70&& e.getY() <= 100) 
		{
			int result = JOptionPane.showConfirmDialog(this, "restart?");
			if (result == 0) {
				// �������¿�ʼ��Ϸ
				// ���¿�ʼ��Ҫ���Ĳ���: 
				// 1)���������,allChess���������ȫ�����ݹ�0.
				// 2) ��Ϸ��Ϣ��ʾ�ص���ʼλ��
				// 3) ����һ������ĸ�Ϊ�ڷ�
				for (int i = 0; i < 19; i++) 
				{
					for (int j = 0; j < 19; j++) 
					{
						allChess[i][j] = 0;
					}
				}
				// ��һ�ַ�ʽ allChess = new int[19][19];
				message = "black first ";
				isBlack = true;
				blackTime = maxTime;
				whiteTime = maxTime;
				if (maxTime > 0) {
					blackMessage = maxTime / 3600 + ":"
							+ (maxTime / 60 - maxTime / 3600 * 60) + ":"
							+ (maxTime - maxTime / 60 * 60);
					whiteMessage = maxTime / 3600 + ":"
							+ (maxTime / 60 - maxTime / 3600 * 60) + ":"
							+ (maxTime - maxTime / 60 * 60);
					t.resume();
				}
				else 
				{
					blackMessage = "no limits";
					whiteMessage = "no limits";
				}
				this.canPlay = true; 
				this.repaint();

			}
		}
		//setting
		if (e.getX() >= 400 && e.getX() <= 470 && e.getY() >= 120&& e.getY() <= 150) 
		{
			String input = JOptionPane.showInputDialog("time?");
			try {
				maxTime = Integer.parseInt(input) * 60;
				if (maxTime < 0) {
					JOptionPane.showMessageDialog(this, "positive!");
				}
				if (maxTime == 0) {
					int result = JOptionPane.showConfirmDialog(this,"restart?");
					if (result == 0) 
					{
						for (int i = 0; i < 19; i++) 
						{
							for (int j = 0; j < 19; j++) 
							{
								allChess[i][j] = 0;
							}
						}
						// ��һ�ַ�ʽ allChess = new int[19][19];
						message = "black first";
						isBlack = true;
						blackTime = maxTime;
						whiteTime = maxTime;
						blackMessage = "no limits";
						whiteMessage = "no limits";
						this.canPlay = true; 
						
						this.repaint();
					}
				}
				if (maxTime > 0) 
				{
					int result = JOptionPane.showConfirmDialog(this,"restart?");
					if (result == 0) 
					{
						for (int i = 0; i < 19; i++) 
						{
							for (int j = 0; j < 19; j++) 
							{
								allChess[i][j] = 0;
							}
						}
						//  allChess = new int[19][19];
						message = "black first";
						isBlack = true;
						blackTime = maxTime;
						whiteTime = maxTime;
						blackMessage = maxTime / 3600 + ":"
								+ (maxTime / 60 - maxTime / 3600 * 60) + ":"
								+ (maxTime - maxTime / 60 * 60);
						whiteMessage = maxTime / 3600 + ":"
								+ (maxTime / 60 - maxTime / 3600 * 60) + ":"
								+ (maxTime - maxTime / 60 * 60);
						t.resume();
						this.canPlay = true; 
						this.repaint();
					}
				}
			} catch (NumberFormatException e1) {
				// TODO Auto-generated catch block
				JOptionPane.showMessageDialog(this, "no right !");
			}
		}
		// information action
		if (e.getX() >= 400 && e.getX() <= 470 && e.getY() >= 170&& e.getY() <= 200) 
		{
			JOptionPane.showMessageDialog(this,"five chess game:five chesses in a line to win");
		}
		// to lose
		if (e.getX() >= 400 && e.getX() <= 470 && e.getY() >= 270&& e.getY() <= 300) 
		{
			int result = JOptionPane.showConfirmDialog(this, "you want to lose?");
			if (result == 0) 
			{
				if (isBlack) 
				{
					JOptionPane.showMessageDialog(this, "black one lose !");
				} 
				else {
					JOptionPane.showMessageDialog(this, "white one lose !");
				}
				canPlay = false;
			}
		}
		// about action
		if (e.getX() >= 400 && e.getX() <= 470 && e.getY() >= 320
				&& e.getY() <= 350) {
			JOptionPane.showMessageDialog(this,"five chess game");
		}
		// exit action
		if (e.getX() >= 400 && e.getX() <= 470 && e.getY() >= 370&& e.getY() <= 400) 
		{
			JOptionPane.showMessageDialog(this, "game over");
			System.exit(0);
		}
	}

	

	private boolean checkWin() {
		boolean flag = false;
		// save how many chesses in a line;
		int count = 1;
		// vertically five chesses in a line ?
		int color = allChess[x][y];
		

		// �жϺ���
		count = this.checkCount(1, 0, color);
		if (count >= 5) {
			flag = true;
		} else {
			// �ж�����
			count = this.checkCount(0, 1, color);
			if (count >= 5) {
				flag = true;
			} else {
				// �ж����ϡ�����
				count = this.checkCount(1, -1, color);
				if (count >= 5) {
					flag = true;
				} else {
					// �ж����¡�����
					count = this.checkCount(1, 1, color);
					if (count >= 5) {
						flag = true;
					}
				}
			}
		}

		return flag;
	}

	// how many connected
	private int checkCount(int xChange, int yChange, int color) {
		int count = 1;
		int tempX = xChange;
		int tempY = yChange;
		while (x + xChange >= 0 && x + xChange <= 18 && y + yChange >= 0&& y + yChange <= 18
				&& color == allChess[x + xChange][y + yChange]) 
		{
			count++;
			if (xChange != 0)xChange++;
			if (yChange != 0) 
			{
				if (yChange > 0)yChange++;
				else 
				{
					yChange--;
				}
			}
		}
		xChange = tempX;
		yChange = tempY;
		while (x - xChange >= 0 && x - xChange <= 18 && y - yChange >= 0
				&& y - yChange <= 18
				&& color == allChess[x - xChange][y - yChange]) {
			count++;
			if (xChange != 0)
				xChange++;
			if (yChange != 0) {
				if (yChange > 0)
					yChange++;
				else {
					yChange--;
				}
			}
		}
		return count;
	}
//OVER_RIDE_RUN
	public void run() {
		//checkTimeLimits
		if (maxTime > 0)
			{
			while (true) 
			{
				if (isBlack) 
				{
					blackTime--;
					if (blackTime == 0) 
					{
						JOptionPane.showMessageDialog(this, "�ڷ���ʱ,��Ϸ����!");
					}
				} else 
				{
					whiteTime--;
					if (whiteTime == 0) 
					{
						JOptionPane.showMessageDialog(this, "�׷���ʱ,��Ϸ����!");
					}
				}
				blackMessage = blackTime / 3600 + ":"
						+ (blackTime / 60 - blackTime / 3600 * 60) + ":"
						+ (blackTime - blackTime / 60 * 60);
				whiteMessage = whiteTime / 3600 + ":"
						+ (whiteTime / 60 - whiteTime / 3600 * 60) + ":"
						+ (whiteTime - whiteTime / 60 * 60);
				this.repaint();
				try 
				{
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(blackTime + " -- " + whiteTime);
			}
		}
	}

}
