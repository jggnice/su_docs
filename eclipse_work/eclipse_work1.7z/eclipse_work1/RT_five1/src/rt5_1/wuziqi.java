package rt5_1;

import javax.swing.*;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.event.*;

@SuppressWarnings("unused")
public class wuziqi
{
   @SuppressWarnings("deprecation")
public static void main(String[] args)
   {
      SimpleFrame frame=new SimpleFrame();
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.show();
   }
}

@SuppressWarnings("serial")
class AboutFrame extends JFrame
{
    public AboutFrame()
    {
       setSize(400,300);
       setResizable(true);
       setTitle("����");
       Toolkit tk=Toolkit.getDefaultToolkit();
       Image ff=tk.getImage("src/rt5_1/image/false.gif");
       setIconImage(ff);
       Dimension screenSize=tk.getScreenSize();
       setLocation((screenSize.width-400)/2,(screenSize.height-300)/2);
       FontPanel fpanel=new FontPanel();
       Container con=getContentPane();
       con.add(fpanel);
    }
}
@SuppressWarnings("serial")
class FontPanel extends JPanel
{
   public void paintComponent(Graphics g)
   {
      super.paintComponent(g);
      Font f=new Font("����",Font.BOLD,22);
      g.setFont(f);
      g.drawString("(������)",10,30);
      f=new Font("����_GB2312",Font.PLAIN,18);
      g.setFont(f);
      g.drawString("����ߣ�Rick carter",10,120);
      g.drawString("�����������Ҳο���ѧϰ��",10,225);
      g.drawString("δ�������������������κ���ҵ�!",10,250);
   }
}

@SuppressWarnings("serial")
class SimpleFrame extends JFrame
{
  
public SimpleFrame()
   {
     setSize(WIDTH,HEIGHT);
     setResizable(false);
     setTitle("�����壨10*10��");
     Toolkit tk=Toolkit.getDefaultToolkit();
     Image img=tk.getImage("src/rt5_1/image/map.gif");
     setIconImage(img);
     Dimension screenSize=tk.getScreenSize();
     setLocation((screenSize.width-WIDTH)/2,(screenSize.height-HEIGHT)/2);

     final AboutFrame aboutFrame=new AboutFrame();

     ImagePanel panel=new ImagePanel();
     Container contentPane=getContentPane();
     contentPane.add(panel);

     JMenuBar menuBar=new JMenuBar();
     setJMenuBar(menuBar);

     JMenu gameMenu=new JMenu("��Ϸ(G)");   //������Ϸ�˵�
     gameMenu.setMnemonic('G');

     //������Ϸ�Ӳ˵���������
     JMenuItem replayItem=new JMenuItem("����",'R');
     replayItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R,InputEvent.CTRL_MASK));
     replayItem.addActionListener(new AbstractAction("����")
                    {
                        public void actionPerformed(ActionEvent event)
                        {
                           ImagePanel.restart();
                        }
                    } );
     JMenuItem optionItem=new JMenuItem("ѡ��",'O');
     optionItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,InputEvent.CTRL_MASK));
     optionItem.addActionListener(new AbstractAction("ѡ��")
                    {
                        /**
						 * 
						 */
						private static final long serialVersionUID = 1L;

						public void actionPerformed(ActionEvent event)
                        {
                           
                        }
                    } );


     JMenuItem exitItem=new JMenuItem("�˳�",'E');
     exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E,InputEvent.CTRL_MASK));
     exitItem.addActionListener(new AbstractAction("�˳�")
                    {
                        /**
						 * 
						 */
						private static final long serialVersionUID = 1L;

						public void actionPerformed(ActionEvent event)
                        {
                           System.exit(0);
                        }
                    } );
     gameMenu.add(replayItem);
     gameMenu.add(optionItem);
     gameMenu.addSeparator(); 
     gameMenu.add(exitItem);
     menuBar.add(gameMenu);

     JMenu helpMenu=new JMenu("����(H)");    //���������˵�
     helpMenu.setMnemonic('H');
     //���������Ӳ˵���������     
     JMenuItem aboutItem=new JMenuItem("����",'A');
     aboutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,InputEvent.CTRL_MASK));
     aboutItem.addActionListener(new AbstractAction("����")
                     {
                         @SuppressWarnings("deprecation")
						public void actionPerformed(ActionEvent event)
                         {
                             aboutFrame.show();
                         }
                     });
     helpMenu.add(aboutItem);
     menuBar.add(helpMenu);

   }
   public static final int WIDTH=560;
   public static final int HEIGHT=450;
   public static final int OUT_OF_FRAME=50;
   public static final int freeBall=0;
   public static final int playerBall=1;
   public static final int computerBall=2;
}

final class ImagePanel extends JPanel
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ImagePanel()
    {
       image=Toolkit.getDefaultToolkit().getImage("src/rt5_1/image/map.gif");
       green=Toolkit.getDefaultToolkit().getImage("src/rt5_1/image/green.gif");
       red=Toolkit.getDefaultToolkit().getImage("src/rt5_1/image/red.gif");
       position=Toolkit.getDefaultToolkit().getImage("src/rt5_1/image/position.gif");
       ired=Toolkit.getDefaultToolkit().getImage("src/rt5_1/image/ired.gif");
       MediaTracker tracker=new MediaTracker(this);
       tracker.addImage(image,1);         //����
       tracker.addImage(green,2);         //������
       tracker.addImage(red,3);           //������
       tracker.addImage(position,4);      //���λ��
       tracker.addImage(ired,5); 
       try
       {
           tracker.waitForID(1);
           tracker.waitForID(2);
           tracker.waitForID(3);
           tracker.waitForID(4);
           tracker.waitForID(5);
       }
       catch(InterruptedException exception) 
       {}

       //ע�������
       addMouseListener(new MouseHandler());
       addMouseMotionListener(new MouseMotionHandler());

	for(i=0;i<10;i++)          //��ʼ������״̬
		for(j=0;j<10;j++)
			ball[i][j] = SimpleFrame.freeBall;
	
	for(i=0;i<10;i++)          //�趨ˮƽ����Ļ�ʤλ��
		for(j=0;j<6;j++)
		{
			for(k=0;k<5;k++)
			{
				ptable[j+k][i][count] = true;
				ctable[j+k][i][count] = true;
			}
			count++;
		}
	for(i=0;i<10;i++)          //�趨��ֱ����Ļ�ʤλ��
		for(j=0;j<6;j++)
		{
			for(k=0;k<5;k++)
			{
				ptable[i][j+k][count] = true;
				ctable[i][j+k][count] = true;
			}
			count++;
		}
	for(i=0;i<6;i++)           //�趨���Խ��߷���Ļ�ʤλ��
		for(j=0;j<6;j++)
		{
			for(k=0;k<5;k++)
			{
				ptable[j+k][i+k][count] = true;
				ctable[j+k][i+k][count] = true;
			}
			count++;
		}
	for(i=0;i<6;i++)           //�趨���Խ��߷���Ļ�ʤλ��
		for(j=9;j>=4;j--)
		{
			for(k=0;k<5;k++)
			{
				ptable[j-k][i+k][count] = true;
				ctable[j-k][i+k][count] = true;
			}
			count++;
		}
	IsComputerTurn = false;
	IsPlayerTurn = true;
    }

    //���ƴ������
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        int FrameWidth=getWidth();
        int FrameHeight=getHeight();
        int x=(FrameWidth-400)/2;
        int y=FrameHeight-400;
        int px=xMouse-(xMouse-x)%40;
        int py=yMouse-(yMouse-y)%40;
        if(px<x)
           px=x;
        if(py<y)
           py=y;
        if(px>(x+360))
           px=x+360;
        if(py>(y+360))
          py=y+360;
        g.drawImage(image,x,y,null);
        g.drawImage(position,px,py,null);
        Font f=new Font("����_GB2312",Font.BOLD,20);
        g.setFont(f);
        g.setColor(new Color(204,66,204));
        g.drawString("�����",5,60);
        g.setColor(new Color(00,99,00));
        g.drawString("���",495,60);
        g.drawImage(red,20,75,null);
        g.drawImage(green,500,75,null);
        g.setColor(Color.black);
        switch(MessageToShow)
        {
          case 0:
               g.drawString("������!",480,140);
               break;
          case 1:
               g.drawString("�ȴ�!",480,140);
               break;
          case 2:
               g.drawString("����ѽ.",480,140);
               break;
          case 3:
               g.drawString("��������",480,140);
               break;
          case 4:
               g.drawString("����ЦЦ!",480,140);
               break;
          case 5:
               g.drawString("ƽ ��!",480,140);
               break;
        }
        for(i=0;i<10;i++)
           for(j=0;j<10;j++)
           {
              if(ball[i][j]==SimpleFrame.playerBall)
              { 
                   px=i*40+3+x;
                   py=j*40+3+y;
                   g.drawImage(green,px,py,null);
              }
              if(ball[i][j]==SimpleFrame.computerBall)
              {
                   px=i*40+3+x;
                   py=j*40+3+y;
                   g.drawImage(red,px,py,null);
              }
           }
        g.drawImage(ired,mComputerLastBall*40+x+3,nComputerLastBall*40+y+3,null);
     }
    /**
     * The Variable Declarations
     * 
     */
     private Image image;
     private Image position;
     private Image green;
     private Image red;
     private Image ired;
     private int xMouse,yMouse;
     @SuppressWarnings("unused")
	private JButton replayButton;

	private static int ball[][] = new int[10][10];
	// POSITIONS
	private static boolean ptable[][][] = new boolean[10][10][192];
	private static boolean ctable[][][] = new boolean[10][10][192];
	// REMEMBER
	private static int playerGrades[][] = new int[10][10];
	private static int computerGrades[][] = new int[10][10];
	private static int TheMaxComputerGrade = 0, TheMaxPlayerGrade = 0;
	// WEIGHT
	private static int win[][] = new int[2][192];
	private static int playerChessCount, computerChessCount;
	// COUNT CHESS
	private static boolean IsPlayerTurn, IsComputerTurn;
	private static boolean GameJustStarted = true, GameIsOver = false;
	private static boolean PlayerWinsTheGame, ComputerWinsTheGame, GameIsATie;
	private static int i, j, k;
	private static int count, mComputerLastBall = SimpleFrame.OUT_OF_FRAME, nComputerLastBall = SimpleFrame.OUT_OF_FRAME;
	private static int n, m;
	//Drop At Point(m,n)
	private static int mAttack, nAttack, mDefend, nDefend;
	private static int MessageToShow = 0;
     //STATE

     @SuppressWarnings("unused")
	private class replayAction implements ActionListener
     {
        public void actionPerformed(ActionEvent event)
        {
            restart();
        }
     }

     //����ƶ��¼�
     private class MouseMotionHandler implements MouseMotionListener
     {
        public void mouseMoved(MouseEvent event)
        {
           xMouse=event.getX();
           yMouse=event.getY();
           repaint();
        }
        public void mouseDragged(MouseEvent event) {}
     }

     //������¼�
     private class MouseHandler extends MouseAdapter
     {
         public void mousePressed(MouseEvent event)
         {
             

          if(!GameIsOver)
          {
        	xMouse=event.getX();
          	yMouse=event.getY();
          
                 if(IsPlayerTurn)
                 {
                     int FrameWidth=getWidth();
                     int FrameHeight=getHeight();
                     int x=(FrameWidth-400)/2;
                     int y=FrameHeight-400-5;
                     if(xMouse>x&&xMouse<(x+400)&&yMouse>y&&yMouse<(y+400))
                     {   m=(int)((xMouse-x)/40);
                         n=(int)((yMouse-y)/40);
                         while(ball[m][n]==SimpleFrame.freeBall)  
                         {  ball[m][n]=SimpleFrame.playerBall;  
                            playerChessCount++;
                            MessageToShow=1;
                            if((computerChessCount==50)&&(playerChessCount==50))
                            {   GameIsATie=true;
                                GameIsOver=true;
                                MessageToShow=5;
                            }
                            for(i=0;i<192;i++)
                            {
                               if(ptable[m][n][i]&&win[0][i]!=7)
                                   win[0][i]++;
                               if(ctable[m][n][i])
                               {
                                  ctable[m][n][i]=false;
                                  win[1][i]=7;   //������ڵ�i�ֻ�ʤ�����в������ٻ�ʤ������Ϊ7
                               }
                            }
	 if(!GameIsOver)
	    {
		  for(i=0;i<=1;i++)
			for(j=0;j<192;j++)
			 {
				if(win[i][j] == 5)
					if(i==0)           //��һ�ʤ
					{
					   PlayerWinsTheGame=true;
                       ComputerWinsTheGame=false;
					   GameIsOver=true;
                       MessageToShow=3;
					   break;
					}
					else               //�������ʤ
					{
					   ComputerWinsTheGame=true;
                       PlayerWinsTheGame=false;
					   GameIsOver=true;
                       MessageToShow=4;
				       break;
					}
				if(GameIsOver)break;
			 }
	    }


        if(GameIsOver)
        {
        	if(GameIsATie)			JOptionPane.showConfirmDialog(
                                         ImagePanel.this,
                                         "ƽ�֣�","ȷ����Ϣ",
                                         JOptionPane.DEFAULT_OPTION,
                                         JOptionPane.INFORMATION_MESSAGE);
        	else if(PlayerWinsTheGame)
                                    JOptionPane.showConfirmDialog(
                                         ImagePanel.this,
                                         "��ϲ�㣡�����ˡ�","ȷ����Ϣ",
                                         JOptionPane.DEFAULT_OPTION,
                                         JOptionPane.INFORMATION_MESSAGE);
            else if(ComputerWinsTheGame)
                                    JOptionPane.showConfirmDialog(
                                         ImagePanel.this,
                                         "�����ˣ�","ȷ����Ϣ",
                                         JOptionPane.DEFAULT_OPTION,
                                         JOptionPane.INFORMATION_MESSAGE);          
         }
        }
       }
      }
        if(!GameIsOver)
        {
        	IsPlayerTurn=false;
            IsComputerTurn=true;
            repaint();
            computerdo();
        }
        	
        	
   }     	
 }
}

    public void computerdo()
    {
      if(!GameIsOver)
         if(IsComputerTurn)
         {
           for(i=0;i<=9;i++)        //COUNT playerGrades
	      for(j=0;j<=9;j++)
	      {
		playerGrades[i][j]=0;
		if(ball[i][j]==SimpleFrame.freeBall)
		  for(k=0;k<192;k++)
		     if(ptable[i][j][k])
		     {
			switch(win[0][k])
			{
			case 1:
			    playerGrades[i][j]+=5;
				break;
			case 2:
				playerGrades[i][j]+=50;
				break;
			case 3:
				playerGrades[i][j]+=100;
				break;
			case 4:
				playerGrades[i][j]+=400;
				break;
			}
		    }
	     }
           for(i=0;i<=9;i++)        //COUNT computerGrades
	     for(j=0;j<=9;j++)
	     {
		computerGrades[i][j]=0;
		if(ball[i][j]==SimpleFrame.freeBall)
		    for(k=0;k<192;k++)
			if(ctable[i][j][k])
			{
			   switch(win[1][k])
			   {
			     case 1:
				computerGrades[i][j]+=5;
				break;
			     case 2:
				computerGrades[i][j]+=50;
				break;
			     case 3:
				computerGrades[i][j]+=100;
				break;
			     case 4:
				computerGrades[i][j]+=4000;
				break;
			   }
			}
	      }
	 if(GameJustStarted)
	 {
		if(ball[4][4]==SimpleFrame.freeBall)
		{
			m = 4;
			n = 4;
		}
		else
		{
			m = 5;
			n = 5;
		}
		GameJustStarted = false;
	 }
	 else
	 {
	    for(i=0;i<10;i++)
	       for(j=0;j<10;j++)
		  if(ball[i][j]==SimpleFrame.freeBall)
		  {
		     if(computerGrades[i][j]>=TheMaxComputerGrade)
		     {
			TheMaxComputerGrade = computerGrades[i][j];   
			mAttack = i;
			nAttack = j;
		     }
		     if(playerGrades[i][j]>=TheMaxPlayerGrade)
		     {
			TheMaxPlayerGrade = playerGrades[i][j];   
			mDefend = i;
			nDefend = j;
		     }
		  }
	    if(TheMaxPlayerGrade>=TheMaxComputerGrade&&TheMaxPlayerGrade>100)
	    {
		m = mDefend;
		n = nDefend;
	    }
	    else 
	    {
		m = mAttack;
		n = nAttack;
	    }
	 }
	 TheMaxComputerGrade = 0;		
	 TheMaxPlayerGrade = 0;
	 ball[m][n] = SimpleFrame.computerBall;
         mComputerLastBall=m;
         nComputerLastBall=n;
	 computerChessCount++;
         MessageToShow=2;
	 if((computerChessCount==50)&&(playerChessCount==50))
	 {
	     GameIsATie = true;
	     GameIsOver = true;
	 }
	 for(i=0;i<192;i++)
	 {
	     if(ctable[m][n][i] && win[1][i] != 7)
		win[1][i]++;
	     if(ptable[m][n][i])
	     {
	 	ptable[m][n][i] = false;
	   	win[0][i]=7;
	     }
	 }
         if(!GameIsOver)
         {
            for(i=0;i<=1;i++)
		for(j=0;j<192;j++)
		{
		    if(win[i][j]==5)
			if(i==0)           //��һ�ʤ
			{
			   PlayerWinsTheGame=true;
               ComputerWinsTheGame=false;
			   GameIsOver=true;
                        MessageToShow=3;
			   break;
			}
			else               //�������ʤ
			{
			   ComputerWinsTheGame=true;
                           PlayerWinsTheGame=false;
			   GameIsOver=true;
                         MessageToShow=4;
			   break;
			}
		    if(GameIsOver)
			break;
		}
	 }
	 IsPlayerTurn=true;        //�������
	 IsComputerTurn=false;
         repaint();
         if(GameIsOver)
         {
            if(GameIsATie)
              JOptionPane.showConfirmDialog(
                     ImagePanel.this,
                     "ƽ�֣�","ȷ����Ϣ",
                     JOptionPane.DEFAULT_OPTION,
                     JOptionPane.INFORMATION_MESSAGE);
            else
                if(PlayerWinsTheGame)
                  JOptionPane.showConfirmDialog(
                       ImagePanel.this,
                       "��ϲ�㣡�����ˡ�","ȷ����Ϣ",
                       JOptionPane.DEFAULT_OPTION,
                       JOptionPane.INFORMATION_MESSAGE);
                else
                    if(ComputerWinsTheGame)
                       JOptionPane.showConfirmDialog(
                            ImagePanel.this,
                            "�����ˣ�","ȷ����Ϣ",
                            JOptionPane.DEFAULT_OPTION,
                            JOptionPane.INFORMATION_MESSAGE);
           restart();
                            
        }
     }
   }

   public static void restart()
   {
	for(i=0;i<10;i++)
	    for(j=0;j<10;j++)
	    {
		playerGrades[i][j]=0;
		computerGrades[i][j]=0;
		ball[i][j]=SimpleFrame.freeBall;
	    }
        count=0;
	for(i=0;i<10;i++)          //�趨ˮƽ����Ļ�ʤλ��
		for(j=0;j<6;j++)
		{
			for(k=0;k<5;k++)
			{
				ptable[j+k][i][count] = true;
				ctable[j+k][i][count] = true;
			}
			count++;
		}
	for(i=0;i<10;i++)          //�趨��ֱ����Ļ�ʤλ��
		for(j=0;j<6;j++)
		{
			for(k=0;k<5;k++)
			{
				ptable[i][j+k][count] = true;
				ctable[i][j+k][count] = true;
			}
			count++;
		}
	for(i=0;i<6;i++)           //�趨���Խ��߷���Ļ�ʤλ��
		for(j=0;j<6;j++)
		{
			for(k=0;k<5;k++)
			{
				ptable[j+k][i+k][count] = true;
				ctable[j+k][i+k][count] = true;
			}
			count++;
		}
	for(i=0;i<6;i++)           //�趨���Խ��߷���Ļ�ʤλ��
		for(j=9;j>=4;j--)
		{
			for(k=0;k<5;k++)
			{
				ptable[j-k][i+k][count] = true;
				ctable[j-k][i+k][count] = true;
			}
			count++;
		}
	for(i=0;i<=1;i++)
	    for(j=0;j<192;j++)
		win[i][j]=0;
	IsComputerTurn=false;
	IsPlayerTurn=true;
    MessageToShow=0;
	count=0;
	computerChessCount=0;
	playerChessCount=0;
	GameJustStarted=true;
	GameIsOver=false;
	PlayerWinsTheGame=false;
	ComputerWinsTheGame=false;
	GameIsATie = false;
	mComputerLastBall = SimpleFrame.OUT_OF_FRAME;
	nComputerLastBall = SimpleFrame.OUT_OF_FRAME;
   }
}