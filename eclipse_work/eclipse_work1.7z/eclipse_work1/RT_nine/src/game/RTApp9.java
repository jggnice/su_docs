package game;

import javax.swing.JFrame;

public class RTApp9
{

	public static void main(String[] args)
	{
		JFrame f = new JFrame();
		f.add(new RTGamePanel());
		f.setVisible(true);		
		f.pack();
		f.setBounds(10, 10, 400, 450);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

}
