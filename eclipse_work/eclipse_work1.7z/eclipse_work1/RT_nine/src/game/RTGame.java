package game;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

@SuppressWarnings("serial")
public class RTGame extends JPanel {

	Font font = new Font("΢���ź�", Font.BOLD, 28);
	/**
	 * Create the panel.
	 */
	public RTGame() {
		setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		panel.add(tabbedPane);
		JPanel panel1 = new JPanel();
		tabbedPane.addTab("game", null, panel1, null);
		panel1.setLayout(new GridLayout(0, 3, 0, 0));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				 if("    ".equals(button_1.getText()))
			        {
			            button_1.setText(button.getText());
			            button.setText("    ");
			        }
			        if("    ".equals(button_3.getText()))
			        {
			            button_3.setText(button.getText());
			            button.setText("    ");
			        }
			        //Figureflag();
			}
		});
		button.setFont(font);
		panel1.add(button);
		System.out.println("button"+ button.getWidth());
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				 if("    ".equals(button.getText()))
			        {
			            button.setText(button_1.getText());
			            button_1.setText("    ");
			        }
			        if("    ".equals(button_2.getText()))
			        {
			            button_2.setText(button_1.getText());
			            button_1.setText("    ");
			        }
			        if("    ".equals(button_4.getText()))
			        {
			            button_4.setText(button_1.getText());
			            button_1.setText("    ");
			        }
			        //Figureflag();	
			}
		});
		button_1.setFont(font);
		panel1.add(button_1);
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				 if("    ".equals(button_1.getText()))
			        {
			            button_1.setText(button_2.getText());
			            button_2.setText("    ");
			        }
			        if("    ".equals(button_5.getText()))
			        {
			            button_5.setText(button_2.getText());
			            button_2.setText("    ");
			        }
			        //Figureflag();
			}
		});
button_2.setFont(font);
		panel1.add(button_2);
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				 if("    ".equals(button.getText()))
			        {
			            button.setText(button_3.getText());
			            button_3.setText("    ");
			        }
			        if("    ".equals(button_4.getText()))
			        {
			            button_4.setText(button_3.getText());
			            button_3.setText("    ");
			        }
			        if("    ".equals(button_6.getText()))
			        {
			            button_6.setText(button_3.getText());
			            button_3.setText("    ");
			        }
			        //Figureflag();
			}
		});
button_3.setFont(font);
		panel1.add(button_3);
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				 if("    ".equals(button_1.getText()))
		         {
		             button_1.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         if("    ".equals(button_3.getText()))
		         {
		             button_3.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         if("    ".equals(button_5.getText()))
		         {
		             button_5.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         if("    ".equals(button_7.getText()))
		         {
		             button_7.setText(button_4.getText());
		             button_4.setText("    ");
		         }
		         //Figureflag();
			}
		});
button_4.setFont(font);
		panel1.add(button_4);
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				 if("    ".equals(btnQ.getText()))
		         {
		             btnQ.setText(button_5.getText());
		             button_5.setText("    ");
		         }
		         if("    ".equals(button_4.getText()))
		         {
		             button_4.setText(button_5.getText());
		             button_5.setText("    ");
		         }
		         if("    ".equals(button_2.getText()))
		         {
		             button_2.setText(button_5.getText());
		             button_5.setText("    ");
		         }
		         //Figureflag();
			}
		});
button_5.setFont(font);
		panel1.add(button_5);
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				 if("    ".equals(button_7.getText()))
		         {
		             button_7.setText(button_6.getText());
		             button_6.setText("    ");
		         }
		         if("    ".equals(button_3.getText()))
		         {
		             button_3.setText(button_6.getText());
		             button_6.setText("    ");
		         }
		         //Figureflag();
			}
		});
button_6.setFont(font);
		panel1.add(button_6);
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				 if("    ".equals(btnQ.getText()))
		         {
		             btnQ.setText(button_7.getText());
		             button_7.setText("    ");
		         }
		         if("    ".equals(button_4.getText()))
		         {
		             button_4.setText(button_7.getText());
		             button_7.setText("    ");
		         }
		         if("    ".equals(button_6.getText()))
		         {
		             button_6.setText(button_7.getText());
		             button_7.setText("    ");
		         }
		         //Figureflag();
			}
		});
button_7.setFont(font);
		panel1.add(button_7);
		btnQ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				 if("    ".equals(button_5.getText()))
		         {
		             button_5.setText(btnQ.getText());
		             btnQ.setText("    ");
		         }
		         if("    ".equals(button_7.getText()))
		         {
		             button_7.setText(btnQ.getText());
		             btnQ.setText("    ");
		         }
		         //Figureflag();
			}
		});

btnQ.setFont(font);
		panel1.add(btnQ);
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("free_info", null, panel_1, null);
		panel_1.setLayout(new BorderLayout(0, 0));

		btnNewGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				setNewGame();
			}
		});
btnNewGame.setFont(font);
		panel_1.add(btnNewGame, BorderLayout.CENTER);
		setNewGame();

	}
	/**
	 * set new Random numbers.
	 */
	public void setNewGame()
	{
	int[] numbers={0,0,0,0,0,0,0,0,0};
	boolean[] flags={false,false,false,false,false,false,false,false,false};
	int tep,tep1;
	int count=0;
//count random numbers
	while(count<9)
	{
		tep=(int)(Math.random()*9);
		if(flags[tep]==false){flags[tep]=true;numbers[count]=tep+1;count++;}
	}
//count reverse numbers
	count=0;
	for(tep=0;tep<8;tep++)
	for(tep1=tep+1;tep1<9;tep1++)
	{
		if((numbers[tep]>numbers[tep1])&&(numbers[tep]!=9)&&(numbers[tep1]!=9))
			count++;
	}
	
	System.out.println(count);
//make  reverse numbers even
	if(count%2==1)
	{	int i=0;
		int select1=0,select2=1;
		while(numbers[i]==9){i++;} select1=i;i++;
		while(numbers[i]==9){i++;} select2=i;
		tep=numbers[select1];numbers[select1]=numbers[select2];numbers[select2]=tep;
	}
//count reverse numbers
	count=0;
	for(tep=0;tep<8;tep++)
	for(tep1=tep+1;tep1<9;tep1++)
	{
		if((numbers[tep]>numbers[tep1])&&(numbers[tep]!=9)&&(numbers[tep1]!=9))
			count++;
	}
	System.out.println(count);
	
	button.setText(""+numbers[0]);if(button.getText().equals("9"))button.setText("    ");		
	button_1.setText(""+numbers[1]);if(button_1.getText().equals("9"))button_1.setText("    ");
	button_2.setText(""+numbers[2]);if(button_2.getText().equals("9"))button_2.setText("    ");
	button_3.setText(""+numbers[3]);if(button_3.getText().equals("9"))button_3.setText("    ");
	button_4.setText(""+numbers[4]);if(button_4.getText().equals("9"))button_4.setText("    ");
	button_5.setText(""+numbers[5]);if(button_5.getText().equals("9"))button_5.setText("    ");
	button_6.setText(""+numbers[6]);if(button_6.getText().equals("9"))button_6.setText("    ");
	button_7.setText(""+numbers[7]);if(button_7.getText().equals("9"))button_7.setText("    ");
	btnQ.setText(""+numbers[8]);if(btnQ.getText().equals("9"))btnQ.setText("    ");
	
	}
	/**
	 * Variables declaration.
	 */
	private JButton btnQ= new JButton("    ");
	private JButton button = new JButton("1");
	private JButton button_1 = new JButton("2");
	private JButton button_2 = new JButton("3");
	private JButton button_3 = new JButton("4");
	private JButton button_4 = new JButton("5");
	private JButton button_5 = new JButton("6");
	private JButton button_6 = new JButton("7");
	private JButton button_7 = new JButton("8");
	private final JButton btnNewGame = new JButton("New Game");
}
