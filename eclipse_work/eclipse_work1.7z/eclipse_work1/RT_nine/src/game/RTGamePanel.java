package game;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.ComboBoxModel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;

@SuppressWarnings("serial")
public class RTGamePanel extends JPanel
{
	private static int Scale = 3;
	private static int Scale2 = Scale * Scale;
	private static int Steps = 0;
	Font font = new Font("΢���ź�", Font.BOLD, 28);
	JComboBox<String> comboBox;
	JPanel panel;
	JPanel bodyPanel;
	private final static String BlankText = "    ";
	static JButton[][] buttons;
	/**
	 * Create the panel.
	 */
	public RTGamePanel()
	{
		setLayout(new BorderLayout(0, 0));

		panel = new JPanel();
		add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));

		JPanel headPanel = new JPanel();
		panel.add(headPanel, BorderLayout.NORTH);
		
		JLabel lblScale = new JLabel("\u8BBE\u7F6E\u9636\u6570");
		headPanel.add(lblScale);
		
		comboBox = new JComboBox<String>();
		comboBox.setModel((ComboBoxModel<String>) new DefaultComboBoxModel<String>(new String[] {"3", "4", "5", "6", "7", "8", "9", "10"}));
		headPanel.add(comboBox);
		
		JButton btnChangscale = new JButton("ChangScale");
		btnChangscale.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				setScale(Integer.parseInt((String) comboBox.getSelectedItem()));
				panel.remove(bodyPanel);
				setNewGame();
				clearSteps();
			}
		});
		headPanel.add(btnChangscale);		
		{
			setNewGame();
		}
	}
	public void setNewGame()
	{
		buttons = new JButton[Scale][Scale];
		bodyPanel = new JPanel();
		panel.add(bodyPanel, BorderLayout.CENTER);
		bodyPanel.setLayout(new GridLayout(Scale, Scale, 0, 0));
		ButtonsActionListener btlistener = new ButtonsActionListener();
		for (int i = 0; i < Scale; i++)
			for (int j = 0; j < Scale; j++)
			{
				buttons[i][j] = new JButton(i * Scale + j + 1 + "");
				buttons[i][j].addActionListener(btlistener);
				buttons[i][j].setFont(font);
				bodyPanel.add(buttons[i][j]);
			}
		buttons[Scale - 1][Scale - 1].setText(BlankText);
		int[] numbers = new int[Scale2];
		int tep, tep1;
		int count = 0;
		int ii = 0;
		for (count = 0; count < Scale2; count++)
		{
			numbers[count] = count + 1;
		}
		// count random numbers
		for (count = 0; count < Scale2; count++)
		{
			tep = (int) (Math.random() * Scale2);
			tep1 = numbers[count];
			numbers[count] = numbers[tep];
			numbers[tep] = tep1;

		}
		// count reverse numbers
		count = 0;
		for (tep = 0; tep < Scale2 - 1; tep++)
			for (tep1 = tep + 1; tep1 < Scale2; tep1++)
			{
				if ((numbers[tep] > numbers[tep1]) && (numbers[tep] != Scale2)
						&& (numbers[tep1] != Scale2))
					count++;
			}

		System.out.println(count);
		/*********************************************************/
		// make reverse numbers even
		for (ii = 0; ii < Scale2; ii++)
		{
			if (numbers[ii] == Scale2)
				break;
		}
		ii = ii / 4;
		if (Scale % 2 == 1)
			ii = 0;
		if ((count + Scale -1 - ii ) % 2 == 1)
		{
			System.out.printf("\nChange: <"+count+","+(Scale -1 - ii)+">");
			int i = 0;
			int select1 = 0, select2 = 1;
			while (numbers[i] == Scale2)
			{
				i++;
			}
			select1 = i;
			i++;
			while (numbers[i] == Scale2)
			{
				i++;
			}
			select2 = i;
			tep = numbers[select1];
			numbers[select1] = numbers[select2];
			numbers[select2] = tep;
		}
		// count reverse numbers
		count = 0;
		for (tep = 0; tep < Scale2 - 1; tep++)
			for (tep1 = tep + 1; tep1 < Scale2; tep1++)
			{
				if ((numbers[tep] > numbers[tep1]) && (numbers[tep] != Scale2)
						&& (numbers[tep1] != Scale2))
					count++;
			}
		System.out.println(count);
		for (count = 0; count < Scale2; count++)
		{
			buttons[count / Scale][count % Scale].setText("" + numbers[count]);
			if ((Scale2 + "").equals(buttons[count / Scale][count % Scale]
					.getText()))
			{
				buttons[count / Scale][count % Scale].setText(BlankText);
			}
		}
	}
	/**
	 * @return the scale
	 */
	public static int getScale()
	{
		return Scale;
	}
	/**
	 * @param scale
	 *            the scale to set
	 */
	public static void setScale(int scale)
	{
		if (scale > 2 && scale < 11)
		{
			Scale = scale;
			Scale2 = scale * scale;
		}
	}
	/**
	 * @return the steps
	 */
	public static int getSteps()
	{
		return Steps;
	}
	/**
	 * @param steps
	 *            the steps to set
	 */
	public static void incSteps()
	{
		Steps++;
	}
	public static void clearSteps()
	{
		Steps = 0;
	}
	public static boolean GameIsOver()
	{
		for (int i = 0; i < Scale2 - 1; i++)
		{
			if (!buttons[i / Scale][i % Scale].getText().equals((i + 1) + ""))
			{
				return false;
			}
		}
		return true;
	}
	class ButtonsActionListener implements ActionListener
	{

		@Override
		public void actionPerformed(ActionEvent arg0)
		{
			int i = 0;
			int j = 0;
			boolean exitflag = false;
			RTGamePanel.incSteps();
			for (i = 0; i < Scale; i++)
			{
				for (j = 0; j < Scale; j++)
				{

					if (arg0.getSource() == buttons[i][j])
					{
						System.out.println(i + "," + j);
						exitflag = true;
						break;
					}
				}
				if (exitflag)
					break;
			}

			if (i > 0)
			{
				if (BlankText.equals(buttons[i - 1][j].getText()))
				{
					buttons[i - 1][j].setText(buttons[i][j].getText());
					buttons[i][j].setText(BlankText);
				}
			}
			if (i < Scale - 1)
			{
				if (BlankText.equals(buttons[i + 1][j].getText()))
				{
					buttons[i + 1][j].setText(buttons[i][j].getText());
					buttons[i][j].setText(BlankText);
				}
			}
			if (j > 0)
			{
				if (BlankText.equals(buttons[i][j - 1].getText()))
				{
					buttons[i][j - 1].setText(buttons[i][j].getText());
					buttons[i][j].setText(BlankText);
				}
			}
			if (j < Scale - 1)
			{
				if (BlankText.equals(buttons[i][j + 1].getText()))
				{
					buttons[i][j + 1].setText(buttons[i][j].getText());
					buttons[i][j].setText(BlankText);
				}
			}
			if (GameIsOver())
			{
				JOptionPane.showMessageDialog(null, "You use " + getSteps()
						+ " Steps !");
			}
		}
	}

}
