/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sixflag1;

import javax.swing.*;
import java.awt.*;

/**
 *
 * @author
 */
public class sixflag1 extends JFrame 
{
      public sixflag1() {
    Image image1 = new ImageIcon("image/us.gif").getImage();
    Image image2 = new ImageIcon("image/ca.gif").getImage();
    Image image3 = new ImageIcon("image/india.gif").getImage();
    Image image4 = new ImageIcon("image/uk.gif").getImage();
    Image image5 = new ImageIcon("image/china.gif").getImage();
    Image image6 = new ImageIcon("image/norway.gif").getImage();

    setLayout(new GridLayout(2, 0, 5, 5));
    add(new ImageViewer(image1));
    add(new ImageViewer(image2));
    add(new ImageViewer(image3));
    add(new ImageViewer(image4));
    add(new ImageViewer(image5));
    add(new ImageViewer(image6));
  }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        // TODO code application logic here
            sixflag1 frame = new sixflag1();
    frame.setTitle("SixFlags");
    frame.setLocationRelativeTo(null); // Center the frame
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(400, 320);
    frame.setVisible(true);
    }
    
}
