package pac1;

public class Ex529 
{
  public static void main(String[] args) 
  {
	 int point;
    int luck = getLuck();
    if (luck == 7 || luck == 11) 
	{
      System.out.println("You win");
      System.exit(0);
    }
    else if (luck == 2 || luck == 3 || luck == 12) 
	{
      System.out.println("You lose");
      System.exit(0);
    }


    do 
	{
	 point = luck;
     System.out.println("point is " + point);
     luck = getLuck();
    } while (luck != 7 && luck != point);

    if (luck == 7)
      System.out.println("You lose");
    else
      System.out.println("You win");
  }

  public static int getLuck() {
    int luck1 = 1 + (int)(Math.random() * 6);
    int luck2 = 1 + (int)(Math.random() * 6);

    System.out.println("You rolled " + luck1 + " + " + luck2 + " = " + (luck1 + luck2));
    return luck1 + luck2;
  }
}
