package pac1;

import java.util.Scanner;

public class Ex53
{
  public static void main(String[] args) 
  {
	    int j ;
		Scanner input =new Scanner(System.in);
		System.out.print("input an interger:");
		j=input.nextInt();
		
		if(isPalindrome(j))System.out.print("the interger is  a Palindrome");
	    else System.out.print("the interger is  not  a Palindrome");
  
  }
  //change 456 to 654
  public static int reverse(int number)
  {
	  int aa,sum=0;
	  aa=number;
	  while(aa>0)
	  {
	  sum=sum*10+aa%10;aa/=10;
	  }
	  return sum;
  }
  //judge if 121 is Palindrome
  public static boolean isPalindrome(int number)
  {
	 return number == reverse(number);
  }
}
