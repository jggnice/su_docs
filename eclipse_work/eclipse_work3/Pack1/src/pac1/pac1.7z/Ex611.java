package pac1;
import java.util.Scanner;
public class Ex611 
{
	public static void main(String[] args)
	{
		Scanner input =new Scanner(System.in);
		System.out.print("input 10 numbers:");
		int  count=0;
		double[] aa = new double[10];
		while(count<10)
		{
			aa[count++] = input.nextDouble();
		}
		System.out.println("the mean is:"+mean(aa));
		System.out.println("the standard is:"+deviation(aa));
		
	}	
	
	public static double deviation(double[] x)
	{
		double sum=0.0;
		for(int i=0;i<x.length;i++)
			sum +=(x[i]-mean(x))*(x[i]-mean(x));
		sum = sum / (x.length - 1);
		sum = Math.sqrt(sum);
		return sum;
	}
	public static double mean(double[] x)
	{
		double sum=0.0;
		for(int i=0;i<x.length;i++)
			sum += x[i];
		sum = sum / x.length;
		return sum;
	}
}
