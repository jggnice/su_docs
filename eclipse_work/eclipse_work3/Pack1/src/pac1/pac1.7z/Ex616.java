package pac1;

public class Ex616 
{
	public static void main(String[] args)
	{
		long startTime,endTime,executionTime;
		
		int[] aa = new int[100000];
		for(int i=0;i<aa.length;i++)
			aa[i]=(int)(Math.random()*100000);
		    int[] bb=aa.clone();
		    int[] cc=aa.clone();
		int keyWord = 888;
		
		System.out.println("the keyWord is "+keyWord);
		//*********************************************
		startTime = System.currentTimeMillis();
		//java.util.Arrays.sort();
		for(int i=0;i<keyWord*keyWord/100;i++)MySearch.LinearSearch(cc, keyWord);
		System.out.println("the index is "+MySearch.LinearSearch(cc, keyWord));			
		endTime = System.currentTimeMillis();
		executionTime = endTime - startTime;
		System.out.println("the LinearSearch executionTime is "+100*executionTime);		
		//*********************************************	
		//*********************************************
		java.util.Arrays.sort(aa);
		startTime = System.currentTimeMillis();
		//
		for(int i=0;i<keyWord*keyWord;i++)MySearch.WhilebinarySearch(aa, keyWord);
			
		System.out.println("the index is "+MySearch.WhilebinarySearch(aa, keyWord));			
		endTime = System.currentTimeMillis();
		executionTime = endTime - startTime;
		System.out.println("the WhileBinarySearch executionTime is "+executionTime);		
		//*********************************************	
		//*********************************************
		java.util.Arrays.sort(bb);
		startTime = System.currentTimeMillis();
		//
		for(int i=0;i<keyWord*keyWord;i++)MySearch.RecursivebinarySearch(bb, keyWord,0,bb.length-1);
		System.out.println("the index is "+MySearch.RecursivebinarySearch(bb, keyWord,0,bb.length-1));
		endTime = System.currentTimeMillis();
		executionTime = endTime - startTime;
		System.out.println("the RecursivebinarySearch executionTime is "+executionTime);		
		//*********************************************	
		
	}
}
