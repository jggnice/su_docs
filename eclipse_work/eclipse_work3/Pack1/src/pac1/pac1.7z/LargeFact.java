package pac1;
import java.math.*;

public class LargeFact
{
	public static void main(String[] args)
	{
		System.out.println("50! is \n"+Lfact(50));
	}
	public static BigInteger Lfact(long n)
	{
		BigInteger result=BigInteger.ONE;
		for(int i=1;i<=n;i++)
			result=result.multiply(new BigInteger(i+""));
		return result;
	}
}