package pac1;

public class MySearch {
	
  public static int LinearSearch(int[] list,int key)
  {
	  for(int i=0;i<list.length;i++)
	  {
		  if(key==list[i]) return i;
	  }
	  return -1;
  }
  public static int WhilebinarySearch(int[] list, int key) 
  {
    int low = 0;int high = list.length - 1;
    

    while (high >= low) 
    {
      int mid = (low+high) / 2;      
      if (key == list[mid])			return mid;
      else if (key < list[mid])		high = mid-1;
      else    						low = mid + 1;
    }

    return -1;
  }
 
  public static int RecursivebinarySearch(int Array[],int key,int low,int high)  
  {  
	  //�ٶ� ���� ���� �ܹ� ���� ���ⳤ�� ���� ֮�� �� index 
      if (low<=high)  
      {  
          int mid = (low+high)/2;
          
          if(key == Array[mid])    return mid;//found index confidently 
          else if(key<Array[mid])  return RecursivebinarySearch(Array,key,low,mid-1);
          									  //found index confidently  
          else                     return RecursivebinarySearch(Array,key,mid+1,high);  
      }  									  //found index confidently
      else  return -1;//found index confidently
  }  
}
