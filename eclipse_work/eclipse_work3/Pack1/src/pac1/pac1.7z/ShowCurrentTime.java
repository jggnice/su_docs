package pac1;

public class ShowCurrentTime
{
	public static void main(String[] args)
	{
		long totalMilliseconds=System.currentTimeMillis();
		long totalseconds=totalMilliseconds/1000;
		long currentseconds=totalseconds%60;
		long totalminutes=totalseconds/60;
		long currentminutes=totalminutes%60;
		long totalhours=totalminutes/60;
		long currenthours=(totalhours+8)%24;
		System.out.println("Current time is "+currenthours+":"+currentminutes+":"+currentseconds+" GMT+8");
	}
}