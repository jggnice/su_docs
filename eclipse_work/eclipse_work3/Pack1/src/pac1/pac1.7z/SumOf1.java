package pac1;
//SumOf.java:	To sum all digits of a number
import java.util.Scanner;
public class SumOf1
{
	public static void main(String[] arg1)
	{	
//		int i=0;
		int j;
		int sum=0;
		
		String str;
		Scanner input =new Scanner(System.in);
		System.out.print("input a number=");
		str=input.next();
		input.close();
//*****************block****************
		for(j=0;j<str.length();j++)
		sum+=str.charAt(j)-'0';
		if(sum==0){System.out.println(0);return;}
		
//*****************block****************
		System.out.println("the sum of all digits is "+sum);
	}
}
