﻿package pac1;
import java.util.Scanner;

public class areainput
{
    public static void main(String[] arg1)
    {
		Scanner input1= new Scanner(System.in);//创建对象
		
		System.out.println("Enter a number for Radius:");
		double radius =input1.nextDouble();//对象操作
		double area = radius * radius * 3.14159;
        System.out.println("The area for the circle of radius "+
		radius+" is "+area);
        input1.close();
    }
}
