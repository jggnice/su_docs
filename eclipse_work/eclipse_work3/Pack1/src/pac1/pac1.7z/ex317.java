package pac1;

import java.util.Scanner;
public class ex317
{
	public static void main(String[] args)
{
	int i,j;
	i=(int)(Math.random()*3);
	String[] aa={"scissor","rock","paper"};	
	String[] bb={".You win",".You lose"," too.It is a draw"};	
		Scanner input =new Scanner(System.in);
		System.out.print("scissor(0),rock(1),paper(2):");
		j=input.nextInt()%3;
//******************************************************************

		if(i==j)
		System.out.println("The computer is "+aa[i]+".You are "+aa[j]+bb[2]);
		else if((i+1)%3==j)
		System.out.println("The computer is "+aa[i]+".You are "+aa[j]+bb[0]);
		else 
		System.out.println("The computer is "+aa[i]+".You are "+aa[j]+bb[1]);
		input.close();
}
}