package pac1;

import java.util.Scanner;
public class ex317434
{
	public static void main(String[] args)
	{
		int last=0,new1=0,j=1;
		while(j<2)
		{
			new1=fun317();
			if((new1==last)&&(new1!=0))j++;
			else j=1;
			last=new1;
		}
		if(last==1)System.out.println("You win two times");
		else System.out.println("The computer win two times");
	}
	public static int fun317()
{
	int i,j;
	i=(int)(Math.random()*3);
	String[] aa={"scissor","rock","paper"};	
	String[] bb={".You win",".You lose"," too.It is a draw"};	
		Scanner input =new Scanner(System.in);
		System.out.print("scissor(0),rock(1),paper(2):");
		j=input.nextInt()%3;
		
//********************processing**********************************************
		if(i==j)
		{System.out.println("The computer is "+aa[i]+".You are "+aa[j]+bb[2]);return  0;}
		else if((i+1)%3==j)
		{System.out.println("The computer is "+aa[i]+".You are "+aa[j]+bb[0]);return 1;}
		else 
		{System.out.println("The computer is "+aa[i]+".You are "+aa[j]+bb[1]);return -1;}
		
}

}