package pac1;

import java.util.Scanner;
public class ex329
{
	public static void main(String[] args)
{
	double x1,y1,x2,y2,r1,r2,distance;

		Scanner input =new Scanner(System.in);
		System.out.print("Enter circle1's center x-,y-coordinates,and radius:");
		x1=input.nextDouble();
		y1=input.nextDouble();
		r1=input.nextDouble();
		System.out.print("Enter circle2's center x-,y-coordinates,and radius:");
		x2=input.nextDouble();
		y2=input.nextDouble();
		r2=input.nextDouble();
		input.close();
//************************processing block******************************************
	distance=Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	if(distance<=Math.abs(r1-r2))
		System.out.print("Circle2 is inside circle1");
	else if(distance<=r1+r2)
		System.out.print("Circle2 overlaps circle1");
	else 		
		System.out.print("Circle2 does not overlaps circle1");
}
}