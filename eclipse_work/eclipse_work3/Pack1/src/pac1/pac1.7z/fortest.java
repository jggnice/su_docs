package pac1;

public class fortest
{
    public static void main(String[] arg1)
    {
		System.out.print("3.0/4+24%36=");
		System.out.println(3.0/4+24%36);
    }
}
