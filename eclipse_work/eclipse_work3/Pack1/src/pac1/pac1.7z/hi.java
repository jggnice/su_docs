package pac1;


public class hi
{
    public static void main(String[] arg1)
    {
		System.out.println("***********************");
        System.out.println("** Welcome to java ! "+16);
		System.out.println("***********************");
		//char[] ch={'a','b','c','d'};
		System.out.println((char)66);
		 
    }
}
