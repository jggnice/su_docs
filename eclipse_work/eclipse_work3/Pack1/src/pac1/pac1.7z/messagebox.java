package pac1;
import javax.swing.*;

public class messagebox
{
    public static void main(String[] arg1)
    {
		JOptionPane.showMessageDialog(null,"now  you come !"+16);
    }
}
